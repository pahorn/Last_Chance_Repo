using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Rand_Fall : MonoBehaviour
{
    public float fallSpeed = 3;
    public float deadzone = -5;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        transform.position = transform.position + (Vector3.down * fallSpeed) * Time.deltaTime;

        if (transform.position.y < deadzone)
        {
            Destroy(gameObject);
        }
    }
}
