using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Laser_Movement : MonoBehaviour
{
    /*
     Handles the movement of the laser
     */


    Vector3 dir;                    // direction in which the bullet will move
    int expand_speed;        // direct modifier on the speed of the laser expanding
    int shrink_speed;        // direct modifier on the speed of the laser shrinking

    bool expand;                    // if true the laser will expand; otherwise the laser will shrink
    float scale_limit;              // limit to which the scale can increase
    
    float laser_width;              // how wide the laser is (localScale.x)

    Bullet_Stats stats;

    // Start is called before the first frame update
    void Start()
    {
        dir = new Vector3(0, 0, 0);

        stats = GetComponent<Bullet_Stats>();

        Transform background = GameObject.Find("Background").transform;

        // calculating distance to the end of the play area based on the object which shot the bullet (the shooter)
        // shooter can be decided by checking the source of the bullet

        if (stats.get_source() == "Player")
        {
            dir = new Vector3(0, 1, 0);
            // using math to calculate the scale_limit
            scale_limit = background.position.y + background.localScale.y / 2 - transform.position.y + 0.25f; 
        }
        else
        {
            dir = new Vector3(0, -1, 0);
            // using math to calculate the scale_limit
            scale_limit = -background.position.y + background.localScale.y / 2 + transform.position.y;
        }

        expand_speed = 14;
        shrink_speed = 9;

        expand = true;
        laser_width = transform.localScale.x;
    }


    // Update is called once per frame
    void Update()
    {
        // Destroying the laser after it has shrunk enough
        if (transform.localScale.y < 0.5f)
        {
            Destroy(this.gameObject);
        }

        float y = transform.localScale.y;

        if (expand)
        {
            // if the laser has expanded enough it will begin to shrink
            if (y + Time.deltaTime * expand_speed > scale_limit)
            {
                expand = false;
            }

            transform.localScale = new Vector3(laser_width, y + Time.deltaTime * expand_speed, 1);
            transform.position += Time.deltaTime * dir * expand_speed/2;

        } else
        {
            transform.localScale = new Vector3(laser_width, y - Time.deltaTime * shrink_speed, 1);
            transform.position += Time.deltaTime * dir * shrink_speed/2;
        }
    }
}
