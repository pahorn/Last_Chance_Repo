using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bullet_Movement_3 : MonoBehaviour
{
    /*
     * Handles the movement of the bullet type 4 (Homing Bullet)
     *  - not completely commentated
     */
    

    Vector3 dir;                    // direction in which the bullet will move
    Vector3 sec_dir;

    GameObject target;              // target that will be tracked

    bool tracking;                  // enables/disables tracking

    float dist;                     // distance between bullet and target at the start

    Transform child;

    float multiplier = 1;

    Bullet_Stats stats;


    // method to parry this type of bullet for Boss_3
    //  - only used in this fight therefore it should only be used there
    public void change_target(GameObject other)
    {
        target = other;
        sec_dir = new Vector3(0, 1, 0);
        dir = sec_dir;
        tracking = true;
    } 


    public void set_tracking_multiplier(float number)
    {
        multiplier = (number > 1) ? number : multiplier;
    }


    // Start is called before the first frame update
    void Start()
    {
        dir = new Vector3(0, 0, 0);         // direction in which the bullet will fly
        sec_dir = new Vector3(0, 0, 0);     // needed to rotate the bullet sprite (basically direction bullet would fly if it is bullet type 1)

        stats = GetComponent<Bullet_Stats>();

        target = null;


        // calculating direction based on the object which shot the bullet (the shooter)
        // shooter can be decided by checking the source of the bullet

        if (stats.get_source() == "Player") // bullet came from player -> need to find the closest enemy to track it
        {
            sec_dir = new Vector3(0, 1, 0);
            dir = sec_dir;

            track_the_closest_enemy();
        }
        else                        // bullet came from enemy -> need to track the player
        {
            sec_dir = new Vector3(0, -1, 0);
            dir = sec_dir;

            track_the_player();
        }

        tracking = true;
        child = transform.GetChild(0);
    }

    // Update is called once per frame
    void Update()
    {
        if (tracking && target!=null) 
        {
            calculating_trajectory();
        }
        transform.position +=  stats.get_speed() * Time.deltaTime * dir;
    }


    // readjusting direction to be more towards the target
    private void calculating_trajectory()
    {
        Vector3 temp = target.transform.position - this.transform.position;
        
        Vector3 tracked_dir = temp.normalized;   // tracked direction
        dir = dir.normalized;

        // adjusted direction
        dir = (dir * multiplier + tracked_dir).normalized;

        // stops the tracking for further calculations
        if ((this.transform.position.y > target.transform.position.y && sec_dir.y == 1) || (this.transform.position.y < target.transform.position.y && sec_dir.y == -1))
        {
            tracking = false;
        }


        // math to adjust the rotation of the bullet strike
        //  - making it look like it's in line between shooter and target

        // angle between calculated direction and base direction of bullet type 1
        float angle = Mathf.Acos(Vector3.Dot(dir,sec_dir)) / Mathf.PI * 180;
        
        angle *= (dir.x > 0) ? -1 : 1;
        child.rotation = Quaternion.Euler(child.eulerAngles.x, child.eulerAngles.y, 90 + angle * sec_dir.y);       // '+ 90' because of the current sprite for the bullet
        // NEEDS CHANGE IF THE SPRITE CHANGES
    }


    void track_the_closest_enemy()
    {
        GameObject[] enemies = GameObject.FindGameObjectsWithTag("Enemy");   // getting all objects with the tag "Enemy"
        GameObject[] bosses = GameObject.FindGameObjectsWithTag("Boss");     // getting all objects with the tag "Boss"

        int joined_length = enemies.Length + bosses.Length;
        GameObject[] enemy_array = new GameObject[joined_length];

        // joining both arrays
        for (int i = 0; i < joined_length; i++)
        {
            if (i < enemies.Length)
            {
                enemy_array[i] = enemies[i];
            }
            else
            {
                enemy_array[i] = bosses[i - enemies.Length];
            }
        }

        // at least one enemy in the entire scene to track
        if (enemy_array.Length > 0)
        {
            // calculate distance between bullet (basically at the player) and enemy[0]
            dist = (enemy_array[0].transform.position - transform.position).magnitude;
            int index = 0;

            // checking all remaining enemies for the distance
            for (int i = 1; i < enemy_array.Length; i++)
            {
                // getting the closest enemy
                float temp_dist = (enemy_array[i].transform.position - transform.position).magnitude;
                if (temp_dist < dist)
                {
                    index = i;
                    dist = temp_dist;
                }
            }

            // calculating the direction to the closest enemy
            dir = (enemy_array[index].transform.position - transform.position).normalized;
            target = enemy_array[index];
        }
    }


    void track_the_player()
    {
        // find the "Player"
        target = GameObject.FindGameObjectWithTag("Player");     

        if (target != null)
        {
            // calculating the direction and distance to the player
            dist = (target.transform.position - transform.position).magnitude;
            dir = (target.transform.position - transform.position).normalized;
        }
    }
}