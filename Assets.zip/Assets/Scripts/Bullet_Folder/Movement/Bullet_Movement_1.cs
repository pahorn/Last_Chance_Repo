using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bullet_Movement_1 : MonoBehaviour
{
    /*
     Handles the movement of the bullet type 1 (Straight bullet)
     */


    Vector3 dir;                    // direction in which the bullet will move
    Bullet_Stats stats;

    // Start is called before the first frame update
    void Start()
    {
        dir = new Vector3(0, 0, 0);

        stats = GetComponent<Bullet_Stats>();

        // calculating direction based on the object which shot the bullet (the shooter)
        // shooter can be decided by checking the source of the bullet
        if (stats.get_source() == "Player")
        {
            dir = new Vector3(0, 1, 0);
        }
        else
        {
            dir = new Vector3(0, -1, 0);
        }
    }

    // Update is called once per frame
    void Update()
    {
        // move the bullet along the calculated direction
        transform.position += dir * stats.get_speed() * Time.deltaTime;
    }
}
