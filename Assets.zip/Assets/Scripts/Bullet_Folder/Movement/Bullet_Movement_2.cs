using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bullet_Movement_2 : MonoBehaviour
{
    /*
     Handles the movement of the bullet type 2 (One-time Tracking Bullet)
     */


    Vector3 dir;                    // direction in which the bullet will move
    Bullet_Stats stats;

    // Start is called before the first frame update
    void Start()
    {
        dir = new Vector3(0, 0, 0);                 // direction in which the bullet will fly
        Vector3 sec_dir = new Vector3(0, 0, 0);     // needed for rotation of the bullet sprite (basically direction bullet would fly if it is bullet type 1)

        stats = GetComponent<Bullet_Stats>();


        // calculating direction based on the object which shot the bullet (the shooter)
        // shooter can be decided by checking the source of the bullet

        if (stats.get_source() == "Player") // bullet came from player -> need to find the closest enemy to track it
        {
            sec_dir = new Vector3(0, 1, 0);
            dir = sec_dir;

            track_the_closest_enemy();
        }
        else   // bullet came from an enemy -> need to track the player
        {
            sec_dir = new Vector3(0, -1, 0);
            dir = sec_dir;

            track_the_player();
        }


        // math to adjust the rotation of the bullet strike
        //  - making it look like it's in line between shooter and target

        // angle between calculated direction and base direction of bullet type 1
        float angle = Mathf.Acos(Vector3.Dot(sec_dir, dir) / (sec_dir.magnitude*dir.magnitude)) / Mathf.PI * 180;
            
        Transform child = this.transform.GetChild(0);
        angle *= (dir.x > 0) ? -1 : 1 ;     
        child.rotation = Quaternion.Euler(child.eulerAngles.x , child.eulerAngles.y , angle * sec_dir.y + child.eulerAngles.z);
    }


    // Update is called once per frame
    void Update()
    {
        // move the bullet along the calculated direction
        transform.position += dir * stats.get_speed() * Time.deltaTime;
    }


    void track_the_closest_enemy()
    {
        GameObject[] enemies = GameObject.FindGameObjectsWithTag("Enemy");   // getting all objects with the tag "Enemy"
        GameObject[] bosses = GameObject.FindGameObjectsWithTag("Boss");     // getting all objects with the tag "Boss"

        int joined_length = enemies.Length + bosses.Length;
        GameObject[] enemy_array = new GameObject[joined_length];

        // joining both arrays
        for (int i = 0; i < joined_length; i++)         
        {
            if (i < enemies.Length)
            {
                enemy_array[i] = enemies[i];
            }
            else
            {
                enemy_array[i] = bosses[i - enemies.Length];
            }
        }

        // at least one enemy in the entire scene to track
        if (enemy_array.Length > 0)
        {
            // calculate distance between bullet (basically at the player) and enemy[0]
            float dist = (enemy_array[0].transform.position - transform.position).magnitude;
            int index = 0;

            // checking all remaining enemies for the distance
            for (int i = 1; i < enemy_array.Length; i++)
            {
                // getting the closest enemy
                float temp_dist = (enemy_array[i].transform.position - transform.position).magnitude;
                if (temp_dist < dist)
                {
                    index = i;
                    dist = temp_dist;
                }
            }

            // calculating the direction to the closest enemy
            dir = (enemy_array[index].transform.position - transform.position).normalized;
        }
    }


    void track_the_player()
    {
        // search for the "Player"
        GameObject player = GameObject.FindGameObjectWithTag("Player");

        if (player != null)
        {
            // calculating the direction to the player
            dir = (player.transform.position - transform.position).normalized;
        }
    }
}