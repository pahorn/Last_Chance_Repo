using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bullet_Stats : MonoBehaviour
{
    /*
    short explanation of the variables:
       - damage of the bullet
            - used for dealing damage

       - speed of the bullet
            - used in the movement of the bullet

       - source of the bullet ("Enemy", "Boss" or "Player") 
            - used in collision handling
     */

    int damage;
    int speed;
    string source;

    // init function which is mostly called after creating a bullet per Instantiate
    public void init(int damage, int speed, string source)
    {
        this.damage = damage;
        this.speed = speed;
        this.source = source;
    }


    // various getter and setter

    public int get_damage()
    {
        return damage;
    }

    public void set_damage(int damage)
    {
        if (damage > 0)
        {
            this.damage = damage;
        }
    }

    public int get_speed()
    {
        return speed;
    }

    public void set_speed(int speed)
    {
        if (speed > 0)
        {
            this.speed = speed;
        }
    }

    public string get_source()
    {
        return source;
    }

    public void set_source(string source)
    {
        this.source = source;
    }
}