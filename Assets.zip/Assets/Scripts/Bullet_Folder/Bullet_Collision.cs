using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bullet_Collision : MonoBehaviour
{
    Bullet_Stats bullet_Stats;

    // decides if the bullet is destroyed when colliding with another bullet of different source
    bool piercing = false;

    public void set_piercing()
    {
        piercing = true;
    }

    // Start is called before the first frame update
    void Start()
    {
        bullet_Stats = GetComponent<Bullet_Stats>();
    }


    // bullet collides with something
    private void OnTriggerEnter2D(Collider2D collision)
    {
        /*
        in short:
            - bullet hits the background : don't destroy
            - bullet hits object of same source : don't destroy
            - bullet hits another bullet with the same source : don't destroy

            - bullet hits anything else : destroy (more or less)
                - deal damage if possible
         */


        // hitting background or object of same source -> don't destroy
        string collision_tag = collision.gameObject.tag;
        if (collision_tag == "Background" || collision_tag == bullet_Stats.get_source())
        {
            return;
        }

        bool should_be_destroyed = true;

        // hits another bullet
        if (collision_tag == "Bullet")
        {
            // bullet has the same source -> don't destroy
            Bullet_Stats other_bullet = collision.gameObject.GetComponent<Bullet_Stats>();
            if (other_bullet.get_source() == bullet_Stats.get_source())
            {
                return;
            }
        }

        Health health_of_collision_object = null;

        bool valid_hit = false;


        // bullet hits anything else and should therefore be (most of the time) destroyed 
        switch (collision_tag)
        {
            case "Player":  // hits a "Player" -> valid hit
                health_of_collision_object = collision.gameObject.GetComponent<Player_Health>();
                if (health_of_collision_object != null)
                {
                    valid_hit = true;
                }
                break;


            case "Enemy":   // hits an "Enemy" -> valid hit
                health_of_collision_object = collision.gameObject.GetComponent<Enemy_Health>();
                if (health_of_collision_object != null)
                {
                    valid_hit = true;
                }
                break;


            case "Buff":    // hits a "Buff" -> more questioning -> valid hit (if it is a "Player" bullet)
                health_of_collision_object = collision.gameObject.GetComponent<Buff_Health>();

                // Buff can only be damaged by Player bullets
                if (health_of_collision_object != null && bullet_Stats.get_source() == "Player")    
                {
                    valid_hit = true;
                }
                break;


            case "Shield":  // hits a "Shield" -> more questioning -> valid hit (if it is a "Player" bullet)
                health_of_collision_object = collision.gameObject.GetComponent<Shield_Health>();
                if (health_of_collision_object != null && bullet_Stats.get_source() == "Player")
                {
                    valid_hit = true;
                    collision.gameObject.GetComponent<Shield_Health>().set_bullet_type(gameObject.name);
                }
                break;


            case "Bullet":  // hits a "Bullet" -> no dealing damage because bullets don't have health
                should_be_destroyed = !piercing;
                break;

     
            case "Boss":    // hits a "Boss" -> valid hit (if it got any Health Script from the Boss)
                health_of_collision_object = collision.gameObject.GetComponent<Boss_3_Health>();
                Health secondary_health = collision.gameObject.GetComponent<Boss1_Health>();

                if (health_of_collision_object != null)
                {
                    valid_hit = true;
                } else if (secondary_health != null)
                {
                    health_of_collision_object = secondary_health;
                    valid_hit = true;
                }
                break;


            case "Weakpoint":   // hits a "Weakpoint" -> valid hit (if it is a "Player" bullet)
                health_of_collision_object = collision.gameObject.GetComponent<Weakpoint_Health>();
                if (health_of_collision_object != null && bullet_Stats.get_source() == "Player")
                {
                    
                    valid_hit = true;
                }
                else
                {
                    return;
                }
                break;


            default:
                Debug.Log("[Message from Bullet_Collision]\n hit something unexpected, that was not planned; " + collision.gameObject.name);
                break;
        }

        // got valid hit -> deal damage
        if (valid_hit)
        {
            int bullet_damage = bullet_Stats.get_damage();
            health_of_collision_object.receive_damage(bullet_damage);
        }

        // only false if it got into the swith case "Bullet"
        if (should_be_destroyed)
        {
            Destroy(this.gameObject);
        }
    }


    // bullet leaves something that it had a collision earlier
    private void OnTriggerExit2D(Collider2D collision)
    {
        // leaving the background -> bullet needs to be destroyed
        // otherwise the bullet would fly indefinitly and exist forever
        if (collision.tag == "Background")
        {
            Destroy(this.gameObject);
        }
    }
}
