using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Laser_Collision : MonoBehaviour
{
    Bullet_Stats bullet_Stats;

    // Start is called before the first frame update
    void Start()
    {
        bullet_Stats = GetComponent<Bullet_Stats>();
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        /*
         in short :
            
            as a player :
                - hit enemy -> deal damage
                - enemy = object with tag "Enemy" or "Boss"                                

            as an enemy : 
                - the 2nd Boss is currently the only enemy that can use the laser
                - so only need to cover specific cases for it
                - hit player -> deal damage
                - player = object with tag "Player"
         
         all nested if clauses are for safety to prevent an error, which should (probably) not occur anymore
         */


        string collision_tag = collision.gameObject.tag;

        Health health_of_collision_object = null;
        bool valid_hit = false;

        // hit an "Enemy" -> valid hit
        if (collision_tag == "Enemy")
        {
            health_of_collision_object = collision.gameObject.GetComponent<Enemy_Health>();
            if (health_of_collision_object != null)
            {
                valid_hit = true;
            }
        }

        // hit a "Boss" and the laser is not shot from the "Boss" -> deal damage
        if (collision_tag == "Boss" && bullet_Stats.get_source() != "Boss")
        {
            // Boss_3_Health has a kind of "anti-player" armor
            health_of_collision_object = collision.gameObject.GetComponent<Boss_3_Health>();
            if (health_of_collision_object != null)
            {
                // this is one way to avoid its armor in order to deal true damage
                collision.gameObject.GetComponent<Boss_3_Health>().receive_damage(bullet_Stats.get_damage(), true);
                valid_hit = false;
            } 
        }

        // hit a "Player" and laser is not shot from the "Player" -> valid hit
        if (collision_tag == "Player" && bullet_Stats.get_source()!= "Player")
        {
            health_of_collision_object = collision.gameObject.GetComponent<Player_Health>();     
            if (health_of_collision_object != null)
            {
                collision.gameObject.GetComponent<Player_Health>().receive_damage(bullet_Stats.get_damage());
                valid_hit = true;
            }

        }

        // got a valid hit -> deal damage
        if (valid_hit)
        {
            int bullet_damage = bullet_Stats.get_damage();
            health_of_collision_object.receive_damage(bullet_damage);

        }
    }
}
