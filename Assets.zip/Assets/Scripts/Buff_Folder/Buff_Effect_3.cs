using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Buff_Effect_3 : Buff_Effect
{
    // Buff, which increases the damage of the Players primary weapon

    float duration;
    float timer;
    GameObject player;
    bool applied;
    static int added_value;
    static int reset_value;
    public Buff_Bar buffBar;

    // Start is called before the first frame update
    void Start()
    {
        // init stuff
        applied = false;
        duration = 10;
        player = GameObject.FindGameObjectWithTag("Player");
        timer = 0;
        added_value = 2;
        reset_value = 0;
        buffBar.SetMaxBuffTime(duration);
        buffBar.SetBuffTime(timer);
    }

    // Update is called once per frame
    void Update()
    {
        timer -= Time.deltaTime;
        buffBar.SetBuffTime(timer);
        // removing the buff is only necessary when it was applied and the timer expired
        if (applied && timer < 0)
        {
            remove_buff();
        }
    }

    override public void activate_buff()
    {
        timer = duration;

        applied = true;

        // get the current bonus damage
        int current_value = player.GetComponent<Gun>().get_additional_bullet_damage();

        // increase the bonus damage
        player.GetComponent<Gun>().set_additional_bullet_damage(current_value + added_value);
    }

    override public void remove_buff()
    {
        // reset the bonus damage (to 0)
        player.GetComponent<Gun>().set_additional_bullet_damage(reset_value);
        applied = false;
    }
}
