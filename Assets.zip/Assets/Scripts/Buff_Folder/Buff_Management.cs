using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Buff_Management : MonoBehaviour
{

    Buff_Effect[] buff_effects;

    [SerializeField]
    GameObject[] buffs;


    // Start is called before the first frame update
    void Start()
    {
        // init buff effect
        buff_effects = new Buff_Effect[3];
        buff_effects[0] = this.gameObject.GetComponentInChildren<Buff_Effect_1>();
        buff_effects[1] = this.gameObject.GetComponentInChildren<Buff_Effect_2>();
        buff_effects[2] = this.gameObject.GetComponentInChildren<Buff_Effect_3>();

    }


    // spawns a buff ot type 0 or type 2
    // - used in the 2nd Boss to make buffs possible to spawn
    // - no buff type 1 since tracking bullets are not optimal for that boss
    public void spawn_buff()
    {
        int chosen_type = Random.Range(0, 2);
        Instantiate(buffs[chosen_type*2], new Vector3(Random.Range(-3.5f, 3.5f), 0, 0), Quaternion.identity);
    }


    // spawns a buff of a random type at the given position
    public void spawn_buff(Vector3 pos)
    {
        int chosen_type = Random.Range(0, 3);
        Instantiate(buffs[chosen_type], pos, Quaternion.identity);
    }


    // will activate the effect of the buff with the given type
    public void apply_buff(int type)
    {
        buff_effects[type].activate_buff();
    }
}