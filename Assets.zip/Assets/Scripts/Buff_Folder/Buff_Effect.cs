using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class Buff_Effect : MonoBehaviour
{
    abstract public void activate_buff();

    abstract public void remove_buff();

    /*
     current view on the implementation of buffs:

    - each buff has a specific effect
        - Buff_1 : fire rate up
        - Buff_2 : changing bullet type
        - Buff_3 : damage up

    - each buff has a duration
        - currently all buffs last 10 seconds
        - after the duration expires the effect of the buff is completely removed
        - each buff has a seperate timer for their duration

    - on collision with the Player
        - the Player will receive the corresponding buff effect for its duration

    - buffs can be active alongside the different other buffs
        - the Player can have all multiple types of active at the same type
        - e.g. Player collides with Buff_1 and 2 seconds later with Buff_3
            - for 8 seconds he will have an increase fire rate and for 10 seconds he will deal more damage

    - buffs of the same type have an interaction
        - it resets the duration of the buff
        - it further amplifies the buff effect (stacking of the effect)
        - e.g. Player has Buff_1 for 2 seconds remaining and "collects" another Buff_1
            - now the Player has 10 seconds of even more fire rate up


     */
}
