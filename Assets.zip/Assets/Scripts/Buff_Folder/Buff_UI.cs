using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Buff_UI : MonoBehaviour
{
    public Text FireRate;
    public Text GunLevel;
    public Text Damage;
    GameObject player;
    float current_FireRate = 0;
    float current_GunLevel = 0;
    float current_Damage = 0;

    void Start() {
      player = GameObject.FindGameObjectWithTag("Player");

      current_FireRate = player.GetComponent<Gun>().get_fire_rate();
      FireRate.text = current_FireRate.ToString();

      current_GunLevel = player.GetComponent<Gun>().get_gun_level();
      GunLevel.text = current_GunLevel.ToString();

      current_Damage = player.GetComponent<Gun>().get_bullet_damage();
      Damage.text = current_Damage.ToString();
    }

    void Update() {
        if (player != null)
        {
            current_FireRate = player.GetComponent<Gun>().get_fire_rate();
            FireRate.text = current_FireRate.ToString();

            current_GunLevel = player.GetComponent<Gun>().get_gun_level();
            GunLevel.text = current_GunLevel.ToString();

            current_Damage = player.GetComponent<Gun>().get_bullet_damage();
            Damage.text = current_Damage.ToString();
        }
    }
}
