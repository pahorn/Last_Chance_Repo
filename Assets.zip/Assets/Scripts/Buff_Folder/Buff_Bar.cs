using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Buff_Bar : MonoBehaviour
{

    public Slider slider;

    public void SetMaxBuffTime(float maxBuffTime) {
      slider.maxValue = maxBuffTime;
    }
   
    public void SetBuffTime(float buffTime) {
      slider.value = buffTime;
    }
}
