using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Buff_Movement : MonoBehaviour
{
    [SerializeField]
    int type;

    Vector3 dir;

    // Start is called before the first frame update
    void Start()
    {
        dir = new Vector3(0,-1,0);
    }

    // Update is called once per frame
    void Update()
    {
        this.transform.position += Time.deltaTime * dir * 2;
    }


    // Destroying the buff if it touches the player
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.tag == "Player")
        {
            // applying the buff to the player
            GameObject.Find("Buff_Manager").GetComponent<Buff_Management>().apply_buff(type);
            Destroy(this.gameObject);
        }
    }


    // Destroying the buff if it gets out of bound
    private void OnTriggerExit2D(Collider2D collision)
    {
        if (collision.tag == "Background")
        {
            Destroy(this.gameObject);
        }
    }


}
