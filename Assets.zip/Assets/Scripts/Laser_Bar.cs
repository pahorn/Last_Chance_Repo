using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Laser_Bar : MonoBehaviour
{
    public Slider slider;
    GameObject player;

    void Start() {
      player = GameObject.FindGameObjectWithTag("Player");
      slider.maxValue = 10;
    }

    void Update() {
      if (player != null)
        {
            slider.value = player.GetComponent<Gun>().get_laser_charge();
        }
    }
}
