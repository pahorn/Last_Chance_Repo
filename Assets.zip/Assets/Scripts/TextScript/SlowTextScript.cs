using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
// For demonstration purposes this script is attached to an empty GameObject in the scene
public class SlowTextScript : MonoBehaviour
{
    public Text textBox;
    public Text bothTextBox;
    [Tooltip("If this is checked there will be a time gap between words. Other wise there is a time gap between each character.")]
    public bool isTimeBetweenWords;
    public float timeBetweenWords, timeBetweenChars;
    string theText;
    // if each word is wanted to be slowly displayed an array will need to be used
    string[] strArray;
    // Use this for initialization
    void Start()
    {
        if (textBox == null || bothTextBox == null)
            Debug.LogError("There is no TextBox assinged!");
        // String should be set to whatever you want to display
        theText = "In einer Welt, die von einer vernichtenden Alieninvasion heimgesucht wurde, findest du dich am Grund des Meeres wieder – einer letzten Zuflucht für die verbliebenen Überlebenden Menschen. Um die Menschheit zu retten und das Licht der Erdoberfläche zu erreichen, musst du dich einer wahren Prüfung stellen. Bist du stark genug, um diese Herausforderung anzunehmen? Umgeben von der unergründlichen Schönheit des Ozeans, kämpfst du  gegen die feindlichen Aliens die in den Tiefen lauern und versuchen, deine Mission zu vereiteln. Mit geschickter Schwimmtechnik und tödlichen Waffen wehrst du dich gegen die Horden, um die letzten Überlebenden zu erreichen. Während deines Abenteuers durch die Unterwasserwelt sammelst du wertvolle Ressourcen und technologische Upgrades, um deine Fähigkeiten zu verbessern. Um die Erde zu retten musst du aus dem Ozean an die Erdoberfläche lebend rauskommen. Doch der Weg zur Erdoberfläche ist von einem mächtigen Boss blockiert – einem gigantischen, biomechanischen Ungetüm, das die Kontrolle über die Unterwasserdomäne übernommen hat. Seine gewaltige Stärke und beeindruckenden Angriffe stellen dich auf die Probe. Du musst all deine Fähigkeiten und dein taktisches Geschick einsetzen, um seine Schwachstellen zu entdecken und ihn zu besiegen. Bist du der Aufgabe gewachsen, dich den Gefahren der Unterwasserwelt zu stellen und den mächtigen Boss zu besiegen? Dein Mut und deine Entschlossenheit sind der Schlüssel, um die Überlebenden zu retten und das Schicksal der Erde zu verändern. Die Zukunft liegt in deinen Händen, und es ist an der Zeit, deine Bestimmung anzunehmen und dich gegen die Aliens zu erheben.";
        // create an array of words
        strArray = theText.Split(' ');
        StartSlowText();
    }
    // This is public to be used when pressing a button(OnClick()) in the UI but it can be setup however you want
    public void StartSlowText()
    {
        if (isTimeBetweenWords)
        {
            // start the coroutine
            StartCoroutine(TextSlower(timeBetweenWords));
        }
        else
        {
            // start the coroutine
            StartCoroutine(TextSlower(timeBetweenChars));
        }
        // the numbers will need to be played with in order to get what looks good
        // WhyNotBoth(0.1, 0.33) seems a good starting point
        StartCoroutine(WhyNotBoth(timeBetweenChars, timeBetweenWords));
    }
    IEnumerator WhyNotBoth(float charTime, float wordTime)
    {
        for (int i = 0; i < strArray.Length; i++)
        {
            foreach (char ch in strArray[i])
            {
                bothTextBox.text += ch;
                yield return new WaitForSeconds(charTime);
            }
            // add a space after each word
            bothTextBox.text += " ";
            yield return new WaitForSeconds(wordTime);
        }
        StopCoroutine(WhyNotBoth(0.0f, 0.0f));
    }
    IEnumerator TextSlower(float time)
    {
        if (isTimeBetweenWords)
        {
            for (int i = 0; i < strArray.Length; i++)
            {
                // dont forget to add a space inbetween each word
                textBox.text += strArray[i] + " ";
                yield return new WaitForSeconds(time);
            }
            StopCoroutine(TextSlower(0.0f));
        }
        else
        {
            foreach (char ch in theText)
            {
                textBox.text += ch;
                // wait between each letter
                yield return new WaitForSeconds(time);
            }
            StopCoroutine(TextSlower(0.0f));
        }
    }
}
