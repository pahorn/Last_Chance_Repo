using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
// For demonstration purposes this script is attached to an empty GameObject in the scene
public class SlowTextScript2 : MonoBehaviour
{
    public Text textBox;
    public Text bothTextBox;
    [Tooltip("If this is checked there will be a time gap between words. Other wise there is a time gap between each character.")]
    public bool isTimeBetweenWords;
    public float timeBetweenWords, timeBetweenChars;
    string theText;
    // if each word is wanted to be slowly displayed an array will need to be used
    string[] strArray;
    // Use this for initialization
    void Start()
    {
        if (textBox == null || bothTextBox == null)
            Debug.LogError("There is no TextBox assinged!");
        // String should be set to whatever you want to display
        theText = "Nachdem du erfolgreich den Kampf am Grund des Meeres überstanden hast, steigst du an die geplagte Erdoberfläche empor. Die verheerenden Auswirkungen der Alieninvasion sind allgegenwärtig – Städte liegen in Trümmern, während eine düstere Atmosphäre den Himmel verdunkelt. Der verzweifelte Widerstand der letzten Überlebenden ruht nun auf deinen Schultern, da du dich den noch grausameren Herausforderungen stellst, die auf dich warten. Als einsamer Krieger durchstreifst du das zerstörte Land, während du gegen eine Vielzahl von Alienkreaturen kämpfst. Diese neuen Feinde sind raffiniert und tödlich, denn sie haben sich den veränderten Umgebungen und den Überlebenskämpfen angepasst. Du musst deine Fähigkeiten und Ausrüstung verbessern, um den feindlichen Angriffen standhalten zu können. Während deines heroischen Vormarschs zur Rettung der Menschheit stößt du auf den mächtigsten Alienboss, den du je gesehen hast. Diese Kreatur, eine fusionierte Mischung aus Technologie und Organismus, beherrscht das Schlachtfeld mit überwältigenden Fähigkeiten. Ihre Angriffe sind verheerend, ihre Verteidigung unüberwindbar. Du musst nicht nur deine Stärke, sondern auch deine Intelligenz einsetzen, um ihre Schwachstellen zu finden und sie zu besiegen";
        // create an array of words
        strArray = theText.Split(' ');
        StartSlowText();
    }
    // This is public to be used when pressing a button(OnClick()) in the UI but it can be setup however you want
    public void StartSlowText()
    {
        if (isTimeBetweenWords)
        {
            // start the coroutine
            StartCoroutine(TextSlower(timeBetweenWords));
        }
        else
        {
            // start the coroutine
            StartCoroutine(TextSlower(timeBetweenChars));
        }
        // the numbers will need to be played with in order to get what looks good
        // WhyNotBoth(0.1, 0.33) seems a good starting point
        StartCoroutine(WhyNotBoth(timeBetweenChars, timeBetweenWords));
    }
    IEnumerator WhyNotBoth(float charTime, float wordTime)
    {
        for (int i = 0; i < strArray.Length; i++)
        {
            foreach (char ch in strArray[i])
            {
                bothTextBox.text += ch;
                yield return new WaitForSeconds(charTime);
            }
            // add a space after each word
            bothTextBox.text += " ";
            yield return new WaitForSeconds(wordTime);
        }
        StopCoroutine(WhyNotBoth(0.0f, 0.0f));
    }
    IEnumerator TextSlower(float time)
    {
        if (isTimeBetweenWords)
        {
            for (int i = 0; i < strArray.Length; i++)
            {
                // dont forget to add a space inbetween each word
                textBox.text += strArray[i] + " ";
                yield return new WaitForSeconds(time);
            }
            StopCoroutine(TextSlower(0.0f));
        }
        else
        {
            foreach (char ch in theText)
            {
                textBox.text += ch;
                // wait between each letter
                yield return new WaitForSeconds(time);
            }
            StopCoroutine(TextSlower(0.0f));
        }
    }
}
