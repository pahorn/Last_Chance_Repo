using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy_Gun : MonoBehaviour
{
    /*
     Implementation of how most of the enemies shoot
     */


    [SerializeField]
    GameObject bullet_1;     // first bullet type    (Straight Bullet)
    [SerializeField]
    GameObject bullet_2;     // second bullet type   (One-time tracking Bullet)
    [SerializeField]
    GameObject bullet_3;     // third bullet type    (Homing Bullet)

    [SerializeField]
    int tracking_multiplier;    // only used for bullet_3

    [SerializeField]
    int bullet_damage;          // damage of the bullet

    [SerializeField]
    int bullet_speed;           // speed of the bullet

    [SerializeField]
    int fire_rate;              // fire rate of the gun (in rpm; rounds per minute)

    [SerializeField]
    int number_of_shots;        // if (number_of_shots > 1) it means there will be a burst of bullets instead of a single one 

    [SerializeField]
    float delay_between_shots_in_burst; // only needed when a burst is shot

    [SerializeField]
    int first_bullet_random_chance;     // chance that the bullet_1 will be fired has

    [SerializeField]
    int second_bullet_random_chance;    // chance that the bullet_2 will be fired

    float shoot_timer;               // acts as the timer for shooting cooldown
    float burst_delay_timer;        // acst as the timer for shots fired in between a burst

    int remaining_shots;            // number of remaining shots in a burst

    bool shots_started_firing;

    [SerializeField]
    bool piercing_bullets = false;

    // Start is called before the first frame update
    void Start()
    {
        // init stuff if it's not set �n the inspector

        if (fire_rate == default)
        {
            fire_rate = 100;

        }

        if (bullet_damage == default)
        {
            bullet_damage = 3;
        }

        if (bullet_speed == default)
        {
            bullet_speed = 5;
        }

        if (number_of_shots == default)
        {
            number_of_shots = 1;
        }

        if (first_bullet_random_chance == default)
        {
            first_bullet_random_chance = 100;
        }

        if (tracking_multiplier == 0)
        {
            tracking_multiplier = 500;
        }

        shoot_timer = 0.2f;
        burst_delay_timer = delay_between_shots_in_burst;
        shots_started_firing = false;
    }


    // Update is called once per frame
    void Update()
    {
        shoot_timer -= Time.deltaTime;
        burst_delay_timer -= Time.deltaTime;

        if (shoot_timer < 0)
        {
            shoot_bullet();
        }
    }

    void shoot_bullet()
    {
        if (!shots_started_firing)
        {
            remaining_shots = number_of_shots;
            shots_started_firing = true;
        }

        // shooting a bullet or a burst of bullets
        if (remaining_shots > 0  &&  burst_delay_timer < 0)
        {
            burst_delay_timer = delay_between_shots_in_burst;
            remaining_shots--;
            random_bullet();
        }

        if (remaining_shots == 0)
        {
            shoot_timer = 60 / fire_rate;
            shots_started_firing = false;
        }

    }

    // create a bullet based on rng and the set values for the random chances
    void random_bullet()
    {
        int r = Random.Range(0, 100);
        GameObject bullet;
        if (r < first_bullet_random_chance)
        {
            bullet = Instantiate(bullet_1, transform.position, Quaternion.identity);

        } else if (r < first_bullet_random_chance + second_bullet_random_chance)
        {
            bullet = Instantiate(bullet_2, transform.position, Quaternion.identity);

        } else
        {
            bullet = Instantiate(bullet_3, transform.position, Quaternion.identity);
            bullet.GetComponent<Bullet_Movement_3>().set_tracking_multiplier(tracking_multiplier);
        }

        // init stats of the created bullet (damage, speed, source)
        bullet.GetComponent<Bullet_Stats>().init(bullet_damage, bullet_speed, this.tag);
        if (piercing_bullets)
        {
            bullet.GetComponent<Bullet_Collision>().set_piercing();
        }
    }
}