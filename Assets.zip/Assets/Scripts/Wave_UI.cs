using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Wave_UI : MonoBehaviour
{

    public Text MaxWave;
    public Text CurrentWave;
    
    public void setCurrentWave(int wave) {
        CurrentWave.text = wave.ToString();
    }

    public void setMaxWave(int number) {
        MaxWave.text = number.ToString();
    }
}
