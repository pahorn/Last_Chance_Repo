using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class laser_boss2 : MonoBehaviour
{//Steuerscript f�r Boss2
    // Start is called before the first frame update
    public GameObject laser;
    int laser_charge = 7;

    //Der Boss bewegt sich zuf�llig und schie�t auf den Spieler. 
    //Zwischendurch stoppt er und feuert einen Laser
    
    //timer zum stoppen
    float timer;
    float timer_move = 4;

    //timer um wieder loszufahren
    float timer2;
    float timer_shoot = 1;

    //soll er sich bewegen?
    bool bewegen;
    //hat er geschossen?
    bool shot;

    void Start()
    {
        bewegen = true;
        shot = false;
    }

    private void Update()
    {
        if(timer < timer_move)
        {    
            timer += Time.deltaTime;
        }
        else
        { //stoppen, einmal schie�en, weiterfahren
            if (timer2 < timer_shoot)
            {
                bewegen = false;
                if (!shot)
                {
                    shoot_laser();
                }
                timer2 += Time.deltaTime;
            }
            else
            {
                bewegen = true;
                timer2 = 0;
                timer = 0;
                shot = false;
            }                    
        }
    }



    public bool get_move()
    {
        return bewegen;
    }

    public void set_move(bool i)
    {
        bewegen = i;
    }

    //feuert laser
    void shoot_laser()
    {    
        GameObject laserbeam = Instantiate(laser, transform.position - new Vector3(0, transform.localScale.y/2, 0), Quaternion.identity);
        laserbeam.GetComponent<Bullet_Stats>().init(f(laser_charge), 1, "Boss");
        laserbeam.transform.localScale = new Vector3(laser_charge * 0.1f + 0.1f, 1, 1);
        shot = true;
    }

    int f(int x)
    {
        int[] a = { 1, 1 };

        for (int i = 0; i < x; i++)
        {
            a[i % 2] = a[0] + a[1];
        }
        return Mathf.Max(a);
    }
}
