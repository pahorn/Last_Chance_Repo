using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Weakpoint_Health : Health
{
    int max_health;
    int health;

    static int buff_limit;
    static int counter;

    float hit_again_timer;

    public void set_max_health(int number)
    {
        max_health = number;
        health = max_health;
    }

    override public int get_max_health()
    {
        return max_health;
    }

    override public int get_health()
    {
        return health;
    }

    void Start()
    {
        max_health = 1;
        health = max_health;
        buff_limit = 4;
        counter = 0;
        hit_again_timer = 0;
    }

    private void Update()
    {
        hit_again_timer -= Time.deltaTime;
    }

    // redirect every Player inflicted damage to the core
    override public void receive_damage(int damage)
    {
        this.gameObject.GetComponentInParent<Boss_3_Health>().receive_damage(damage, true);
        
        if (hit_again_timer < 0)
        {
            counter++;
            hit_again_timer = 0.5f;
        }

        if (counter >= buff_limit)
        {
            counter = 0;
            GameObject buff_manager = GameObject.Find("Buff_Manager");

            if(buff_manager!= null)
            {
                buff_manager.GetComponent<Buff_Management>().spawn_buff();
            }
        }
                
    }


}
