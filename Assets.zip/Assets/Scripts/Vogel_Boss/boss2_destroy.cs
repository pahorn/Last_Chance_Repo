using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class boss2_destroy : MonoBehaviour
{
    //Levelwechsel weil Boss besiegt
    // Start is called before the first frame update
    private void OnDestroy()
    {
        GameObject lvl = GameObject.FindGameObjectWithTag("lvl");
        if (lvl != null)
        {
            lvl.GetComponent<lvl>().win_lvl();
        }

    }
}
