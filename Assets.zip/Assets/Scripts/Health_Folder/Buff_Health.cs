using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Buff_Health : Health
{
    int max_health;
    int health;

    override public int get_max_health()
    {
        return max_health;
    }

    override public int get_health()
    {
        return health;
    }

    void Start()
    {
        max_health = 3;
        health = max_health;
    }

    // damaging the buff will decrease its health by 1 every time with no regards to the amount of damage
    // making it more like hitpoints than actual health
    override public void receive_damage(int damage)
    {
        health--;
        if (health < 1)
        {
            // healing the "Player" by doing negative damage
            int player_max_health = GameObject.FindGameObjectWithTag("Player").GetComponent<Player_Health>().get_max_health();
            GameObject.FindGameObjectWithTag("Player").GetComponent<Player_Health>().receive_damage((int) -(player_max_health * 0.1));
            Destroy(this.gameObject);
        }
    }
}
