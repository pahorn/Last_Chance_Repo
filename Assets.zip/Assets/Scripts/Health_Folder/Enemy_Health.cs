using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy_Health : Health
{
    [SerializeField]
    int max_health;
    int health;

    public Health_Bar healthBar;

    public void set_max_health(int number)
    {
        max_health = number;
        health = max_health;
    }

    override public int get_max_health()
    {
        return max_health;
    }

    override public int get_health()
    {
        return health;
    }

    void Start()
    {
        if (max_health == default)
        {
            max_health = 20;
        }

        health = max_health;
        healthBar.SetMaxHealth(max_health);
    }


    override public void receive_damage(int damage)
    {

        health -= damage;
        if (health < 1)
        {
            // spawning a buff on the "dead" enemies position
            GameObject.Find("Buff_Manager").GetComponent<Buff_Management>().spawn_buff(this.transform.position);
            Destroy(this.gameObject);
        }

        // avoid overheal if damage was negative
        health = Mathf.Min(health, max_health);

        //Debug.Log("[Message from Enemy_Health]\nEnemy took "+damage+" damage; current health " + health);
        healthBar.SetHealth(health);
    }


    private void OnDestroy()
    {
        GameObject lvl = GameObject.FindGameObjectWithTag("lvl");

        GameObject shield = GameObject.FindGameObjectWithTag("Boss");

        if (lvl != null)
        {
            lvl.GetComponent<lvl>().decrease_enemy_alive();
        }

        if (shield != null) //Fallunterscheidung zwischen normalem Gegner und Miniom
        {
            if (gameObject.name == "minom(Clone)")
            {
                shield.GetComponent<spawner_boss1>().set_alive();
            }
        }
    }
}
