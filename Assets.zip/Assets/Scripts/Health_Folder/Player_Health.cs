using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player_Health : Health
{
    int max_health;
    int health;

    float invincibility_timer;

    lvl lvl;

    public Health_Bar healthBar;

    public void set_max_health(int number)
    {
        max_health = number;
        health = max_health;
    }

    override public int get_max_health()
    {
        return max_health;
    }

    override public int get_health()
    {
        return health;
    }


    void Start()
    {
        max_health = 100;
        health = max_health;
        invincibility_timer = 0;
        lvl = GameObject.FindGameObjectWithTag("lvl").GetComponent<lvl>();
        healthBar.SetMaxHealth(max_health);
    }

    void Update()
    {
        invincibility_timer -= Time.deltaTime;
    }


    // check whether or not the player should receive damage
    private bool player_invincibility(int damage)
    {
        bool dodge_damage_negate = GetComponent<Player_Movement>().dodge_invincibility();
        bool last_damage_negate = (invincibility_timer > 0);

        return (dodge_damage_negate || last_damage_negate) && damage > 0;
    }

    // check if the bullet hit the player during a dodge to increase laser_charge
    public void dodge_collision(int damage)
    {
        if (GetComponent<Player_Movement>().dodge_invincibility() && damage >= 0)
        {
            GetComponent<Gun>().increase_laser_charge();
        }
    }

    override public void receive_damage(int damage)
    {
        dodge_collision(damage);

        // check if the player is currently invincible towards damage
        if (player_invincibility(damage))
        {
            return;
        }

        // deal the actual damage
        health -= damage;

        // make the player immune towards damage for a brief period of time
        if (damage > 0)
        {
            invincibility_timer = 0.25f;
        }

        
        if (health < 1)
        {
            Destroy(this.gameObject);
        }
        
        // avoid overheal if damage was negative
        health = Mathf.Min(health, max_health);
        
        healthBar.SetHealth(health);
    }

    private void OnDestroy()
    {
        Debug.Log("[Message from Player_Health]\n you lose (Player no longer alive)");
        if (lvl != null && health < 1)
        {
            lvl.restart_lvl();
        }
    }
}
