using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class Health : MonoBehaviour
{
    /*
    Every object that can be damaged will have some subclass of Health attached to it
     - the listed functions have some kind of overall purpose and therefore need to be implemented in every subclass

    get_max_health() and get_health() 
     - are currently cosmetic functions with zero calls
     
    receive_damage(int damage) 
     - is used in collision handling for the bullets and the laser
     - can be used to deal damage to the gameobject
     - can be used to heal some gameobjects
     - will destroy the gameobject in the function if enough damage is dealt to it
     */

    abstract public int get_max_health();

    abstract public int get_health();

    abstract public void receive_damage(int damage);
}
