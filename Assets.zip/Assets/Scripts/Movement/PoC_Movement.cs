using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PoC_Movement : MonoBehaviour
{

    /*
     *  Basically just a test to show the effect of tracking
     *  copied from PlayerMovement with different key inputs to move the object
     *
     *
     */


    Vector3 dir;                    // direction in which to move
    public int speed_modifier;      // direct multiplier on speed of the plaver


    // dodge variables
    float dodge_cooldown;           // time that has to pass until a new dodge can be done
    float dodge_cooldown_timer;
    float dodge_duration;           // modifier how long the dodge lasts
    float dodge_duration_timer;
    public int dodge_speed;         // modifier on how fast the player moves during the dodge

    Boundary_Clipping boundary;


    public bool dodge_invincibility()
    {
        return dodge_duration_timer > 0;
    }

    int dodge_dir;                  // direction of the dodge



    // Start is called before the first frame update
    void Start()
    {
        // initializing a few variables


        if (speed_modifier == default)
        {
            speed_modifier = 4;
        }
        if (dodge_speed == default)
        {
            dodge_speed = 3 * speed_modifier;
        }


        dodge_cooldown = 1.5f;
        dodge_cooldown_timer = 0;
        dodge_duration = 0.3f;
        dodge_duration_timer = 0;

        dir = new Vector3(0, 0, 0);

        boundary = GetComponent<Boundary_Clipping>();
    }


    // Update is called once per frame
    void Update()
    {
        dir = new Vector3(0, 0, 0);

        dodge_duration_timer -= Time.deltaTime;
        dodge_cooldown_timer -= Time.deltaTime;

        // ignore further input if a dodge should be done
        if (dodge_duration_timer > 0)
        {
            dir = dodge_speed * new Vector3(dodge_dir, 0, 0);

        }
        else
        {

            // check if the player intends to move
            dir_input();

            // check if the player intends to dodge
            dodge_input();
        }


        Vector3 new_position = transform.position + Time.deltaTime * dir;


        // ensures, that the player stays in its designed area
        dir = boundary.boundary_clipping(dir, new_position, "Enemy");

        transform.position += Time.deltaTime * dir;
    }



    // implemented so that opposite input cancel each other
    //  e.g. player presses left (A) and right (D) results in no horizontel movement
    private void dir_input()
    {


        if (Input.GetKey(KeyCode.UpArrow))            // player wants to move up
            dir.y = 1;

        if (Input.GetKey(KeyCode.DownArrow))            // player wants to move down
            dir.y = -1;

        if (Input.GetKey(KeyCode.LeftArrow))            // playe wants to move left
            dir.x = -1;

        if (Input.GetKey(KeyCode.RightArrow))            // player wants to move right
            dir.x = 1;

        dir *= speed_modifier;
    }



    // dodging == double-tap in a horizontal direction within a specific amount of time
    private void dodge_input()
    {
        // player dodged recently -> another dodge can not be done again yet
        if (dodge_cooldown_timer > 0)
        {
            return;
        }

        // no input for dodge -> no need to do anything further
        if (Input.GetKeyDown(KeyCode.LeftShift) && (dir.x != 0))
        {
            prep_dodge();

        }

    }

    // returns the direction of the dodge
    private void prep_dodge()
    {
        dodge_dir = (dir.x > 0) ? 1 : -1;

        dodge_duration_timer = dodge_duration;  // how long the dodge-move lasts
        dodge_cooldown_timer = dodge_cooldown;  // how much time has to pass before another dodge-move can be made
    }
}