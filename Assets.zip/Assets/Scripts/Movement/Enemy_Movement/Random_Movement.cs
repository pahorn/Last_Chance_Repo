using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Random_Movement : Movement
{
    /*
     Implementation of a Movement_Behaviour
        - will move in a radnom direction for a random period of time
        - afterwards a new random direction and a new random period of time will be generated
            - x and y components have their own timer and will therefore be generated independently from each other
        - and so it continues
     */

    Vector3 dir;
    Boundary_Clipping boundary;

    [SerializeField]
    float movement_speed;

    float x_change_timer;
    float y_change_timer;

    // Start is called before the first frame update
    void Start()
    {
        if (movement_speed == default)
        {
            movement_speed = 1;
        }

        boundary = GetComponent<Boundary_Clipping>();

        dir = new Vector3(get_radom_direction_value(), get_radom_direction_value(), 0);

        x_change_timer = Random.Range(0.1f, 0.7f);
        y_change_timer = Random.Range(0.1f, 0.7f);
    }

    // Update is called once per frame
    void Update()
    {
        x_change_timer -= Time.deltaTime;
        y_change_timer -= Time.deltaTime;

        // create new x.direction and its timer
        if (x_change_timer < 0)
        {
            x_change_timer = Random.Range(0.5f, 1f);
            dir.x = get_radom_direction_value();
        }

        // create new y.direction and its timer
        if (y_change_timer < 0)
        {
            y_change_timer = Random.Range(0.5f, 1f);
            dir.y = get_radom_direction_value();
        }

        // calculate position in the next frame
        Vector3 new_position = transform.position + Time.deltaTime * dir * movement_speed;

        // call the boundary_clipping function to ensure it will be in its area
        dir = boundary.boundary_clipping(dir, new_position, this.tag);

        transform.position += Time.deltaTime * dir * movement_speed;
    }

    float get_radom_direction_value()
    {
        return Random.Range(-1, 2);
    }

    override public float get_speed()
    {
        return movement_speed;
    }

    override public void set_speed(float i)
    {
        movement_speed = i;
    }
}
