using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Screen_Saver_Movement : Movement
{
     /*
     Implementation of a Movement_Behaviour
        - will move in a radnom direction at the beginning
        - if the object would leave its designated area in a direction 
            -> the object will move in the opposite direction
     */


    Vector3 dir;
    Boundary_Clipping boundary;

    [SerializeField]
    float movement_speed;

    // Start is called before the first frame update
    void Start()
    {
        if (movement_speed == default)
        {
            movement_speed = 1;
        }

        dir = get_start_direction();
        boundary = GetComponent<Boundary_Clipping>();
    }

    // Update is called once per frame
    void Update()
    {
        // calculate position in the next frame
        Vector3 new_position = transform.position + Time.deltaTime * dir * movement_speed;

        // call the boundary_clipping function to ensure it will be in its area
        Vector3 clipped_dir = boundary.boundary_clipping(dir, new_position, this.tag);

        // hit left or right wall -> change x.direction
        if (clipped_dir.x == 0)
        {
            dir.x *= -1;
        }

        // hit top or bottom wall -> change y.direction
        if (clipped_dir.y == 0)
        {
            dir.y *= -1;
        }

        transform.position += Time.deltaTime * dir * movement_speed;
    }

    Vector3 get_start_direction()
    {
        int x_dir = Random.Range(0, 2);
        int y_dir = Random.Range(0, 2);

        if (x_dir == 0)
        {
            x_dir = -1;
        }

        if (y_dir == 0)
        {
            y_dir = -1;
        }

        return new Vector3(x_dir, y_dir, 0);
    }

    override public float get_speed()
    {
        return movement_speed;
    }

    override public void set_speed(float i)
    {
        movement_speed = i;
    }
}
