
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Down_Movement : Movement
{
    [SerializeField]
    float movement_speed;

    Vector3 dir;
    Boundary_Clipping boundary;



    float x_change_timer;
    float y_change_timer;

    // Start is called before the first frame update
    void Start()
    {
        if (movement_speed == default)
        {
            movement_speed = 1;
        }

        boundary = GetComponent<Boundary_Clipping>();

        dir = get_radom_direction();


        x_change_timer = Random.Range(0.1f, 0.7f);
        y_change_timer = Random.Range(0.1f, 0.7f);


    }

    // Update is called once per frame
    void Update()
    {

        x_change_timer -= Time.deltaTime;
        y_change_timer -= Time.deltaTime;


        if (x_change_timer < 0)
        {
            x_change_timer = Random.Range(0.5f, 1f);
            dir.x = get_radom_direction().x;
        }

        if (y_change_timer < 0)
        {
            dir.y = -1;
        }


        Vector3 new_position = transform.position + Time.deltaTime * dir * movement_speed;

        Vector3 clipped_dir = boundary.boundary_clipping(dir, new_position, this.tag);

        if (clipped_dir.x != dir.x)
        {
            dir.x *= -1;
            x_change_timer = Random.Range(3f, 5f);
        }

        if (clipped_dir.y != dir.y)
        {
            dir.y *= -1;
            y_change_timer = Random.Range(0.1f, 0.5f);
        }

        transform.position += Time.deltaTime * dir * movement_speed;
    }

    Vector3 get_radom_direction()
    {
        int x_dir = Random.Range(-1, 2);
        int y_dir = Random.Range(-1, 2);

        return new Vector3(x_dir, y_dir, 0);
    }
    override public float get_speed()
    {
        return movement_speed;
    }

    override public void set_speed(float i)
    {
        movement_speed = i;
    }
}
