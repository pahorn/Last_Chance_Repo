using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Boundary_Clipping : MonoBehaviour
{
    /*
     Implementation of a function which return a Vector3
        - acts more or less as a substitute for collision with the boundary of the playfield area
        - every moving object which is not a bullet or a buff (so "Player", "Enemy" and "Boss") will go through this function
        - will prevent them from leaving their designated areas

       if the gameobject would go outside their designated area in any side (can be checked through future_position and source)
       the respective direction vector will be cut to 0 (x or y valus of dir)
         - e.g. object will leave on the right side (meaning the x.value of dir is originally -1)
         - will be cut to 0 so that the object will stay in its area in the next frame
     */

    public Vector3 boundary_clipping(Vector3 dir, Vector3 future_position, string source)
    {
        Transform playfield = null;

        // designated playfield can be selected by the give source
        if (source == "Player")
        {
            playfield = GameObject.Find("Player_Playfield").transform;
        }
        else if (source == "Enemy" || source == "Boss")
        {
            playfield = GameObject.Find("Enemy_Playfield").transform;
        }

        if (playfield == null)
        {
            Debug.Log("[Message from Boundary_Clipping]\n method is accessed by something not accounted for\n 'Player', 'Boss' or 'Enemy' expected; '" + source + "' received");
            Destroy(this.gameObject);
        }

        Vector3 scale = this.transform.localScale;


        // check left side
        if (future_position.x - scale.x / 2 < playfield.position.x - playfield.localScale.x / 2)
        {
            dir.x = 0;
        }

        // check right side
        if (future_position.x + scale.x / 2 > playfield.position.x + playfield.localScale.x / 2)
        {
            dir.x = 0;
        }

        // check top side
        if (future_position.y + scale.y / 2 > playfield.position.y + playfield.localScale.y / 2)
        {
            dir.y = 0;
        }

        // check bottom side
        if (future_position.y - scale.y / 2 < playfield.position.y - playfield.localScale.y / 2)
        {
            dir.y = 0;
        }

        return dir;
    }
}
