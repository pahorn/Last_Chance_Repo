using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Dodge_Bar : MonoBehaviour
{

    public Slider slider;

    public void SetMaxDodge(float maxDodge) {
      slider.maxValue = maxDodge;
      slider.value = maxDodge;
    }
   
    public void SetDodge(float dodge) {
      slider.value = dodge;
    }
}
