using UnityEngine;

public class Player_Movement : Movement
{

    /*
     *  Handles the Movement of the player
     *      - movement in a direction
     *      - dodge implementation
     */

    public Dodge_Bar dodgeBar;

    Vector3 dir;                    // direction in which to move
    float movement_speed;           // direct multiplier on speed of the plaver
    float og_speed;


    // dodge variables
    float dodge_cooldown;           // time that has to pass until a new dodge can be done
    float dodge_cooldown_timer;     
    float dodge_duration;           // modifier how long the dodge lasts
    float dodge_duration_timer;     
    float dodge_speed;         // modifier on how fast the player moves during the dodge

    Boundary_Clipping boundary;

   
    public bool dodge_invincibility()
    {
        return dodge_duration_timer > 0;
    }

    int dodge_dir;                  // direction of the dodge



    // Start is called before the first frame update
    void Start()
    {
      // initializing a few variables
        movement_speed = 4;
        dodge_speed = 3 * movement_speed;
        og_speed = movement_speed;

        dodge_cooldown = 1.5f;
        dodge_cooldown_timer = 0;
        dodge_duration = 0.3f;
        dodge_duration_timer = 0;

        dodgeBar.SetMaxDodge(dodge_cooldown);

        dir = new Vector3(0, 0, 0);

        boundary = GetComponent<Boundary_Clipping>();
    }


    // Update is called once per frame
    void Update()
    {
        dir = new Vector3(0, 0, 0);

        dodge_duration_timer -= Time.deltaTime;
        dodge_cooldown_timer -= Time.deltaTime;

        dodgeBar.SetDodge(dodge_cooldown_timer);
        
        // ignore further input if a dodge should be done
        if (dodge_duration_timer > 0)
        {
            dir = dodge_speed * new Vector3(dodge_dir, 0, 0);

        } else
        {
            // check if the player intends to move
            dir_input();

            // check if the player intends to dodge
            dodge_input();
        }

        Vector3 new_position = transform.position + Time.deltaTime * dir;

        // ensures, that the player stays in its designed area
        dir = boundary.boundary_clipping(dir, new_position, "Player");

        transform.position += Time.deltaTime * dir;
    }


    // implemented so that opposite input cancel each other
    //  e.g. player presses left (A) and right (D) results in no horizontel movement
    private void dir_input()
    {
        Vector2 new_dir = new Vector2(0, 0);

        if (Input.GetKey(KeyCode.W))            // player wants to move up
            dir.y = 1;

        if (Input.GetKey(KeyCode.S))            // player wants to move down
            dir.y = -1;

        if (Input.GetKey(KeyCode.A))            // playe wants to move left
            dir.x = -1;

        if (Input.GetKey(KeyCode.D))            // player wants to move right
            dir.x = 1;
  
        dir *= movement_speed;
    }


    // dodging == double-tap in a horizontal direction within a specific amount of time
    private void dodge_input()
    {
        // player dodged recently -> another dodge can not be done again yet
        if (dodge_cooldown_timer > 0)
        {
            return;
        }

        // no input for dodge -> no need to do anything further
        if (Input.GetKeyDown(KeyCode.LeftShift) && (dir.x != 0))
        {
            preparing_dodge();
        }
    }

    // returns the direction of the dodge
    private void preparing_dodge()
    {
        dodge_dir = (dir.x > 0) ? 1 : -1;

        dodge_duration_timer = dodge_duration;  // how long the dodge-move lasts
        dodge_cooldown_timer = dodge_cooldown;  // how much time has to pass before another dodge-move can be made
    }

    override public float get_speed()
    {

        return og_speed;
    }

    override public void set_speed(float i)
    {
        movement_speed = i;
    }
}
