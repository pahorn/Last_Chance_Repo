using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class Movement : MonoBehaviour
{
    /*
     set_speed(float i) and get_speed() are currently solely needed for the Slow_Effect
        - does a better solution exists for that problem : yes
        - does it currently work : yes
        - does it currently need to change : not yet
     */

    abstract public void set_speed(float i);

    abstract public float get_speed();
}
