using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class SecondaryWeapon_UI : MonoBehaviour
{

    public Slider slider;

    public void SetMaxWeaponCharge(int maxWeaponCharge) {
      slider.maxValue = maxWeaponCharge;
      slider.value = maxWeaponCharge;
    }
   
    public void SetWeaponCharge(int weaponCharge) {
      slider.value = weaponCharge;
    }
}
