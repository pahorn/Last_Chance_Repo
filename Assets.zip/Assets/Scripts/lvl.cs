using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class lvl : MonoBehaviour
{
    

    public bool lvl_end = false;
    public string next_lvl_name;

    public int enemy_count;         //wieviele gegner diese welle spawnen sollen
    public int enemy_alive;         //wieviele gegner auf einmal spawnen sollen

    

    public void win_lvl()          
    {
        //lvl wechsel, wenn lvl bestanden oder Boss besiegt

        if (!lvl_end)
        {
            if (next_lvl_name != "")
            {
                SceneManager.LoadScene(next_lvl_name);
                lvl_end = true;
            }
        }
    }

    //lvl neustart wenn Spieler gestorben
    public void restart_lvl()
    {
        if (!lvl_end)
        {              
                SceneManager.LoadScene(SceneManager.GetActiveScene().name);
                lvl_end = true;

        }

    }

    public void decrease_enemy_counter()
    {
        enemy_count--;
    }

    public void decrease_enemy_alive()
    {
        enemy_alive--;
    }

    public void increase_enemy_alive()
    {
        enemy_alive++;
    }
}
