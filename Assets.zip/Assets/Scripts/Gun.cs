using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Gun : MonoBehaviour
{
    /*
     Implementation of how the player shoots
     */


    [SerializeField]
    GameObject bullet_1;     // bullet type 1   (Straight Bullet)
    [SerializeField]
    GameObject bullet_2;     // bullet type 2   (One-time tracking Bullet)
    [SerializeField]
    GameObject bullet_3;     // bullet type 3   (Homing Bullet)

    [SerializeField]
    GameObject laser;

    public SecondaryWeapon_UI secondaryWeapon;

    // variables for the secondary weapon
    int storage;
    int storage_limit;
    float storage_recharge;
    float storage_timer;
    float secondary_timer;


    // variables for the laser
    int laser_charge;
    int laser_max_charge;

    public void increase_laser_charge()
    {
        laser_charge = Mathf.Min(++laser_charge, laser_max_charge);
    }

    public int get_laser_charge()
    {
        return laser_charge;
    }

    public int get_laser_max_charge()
    {
        return laser_max_charge;
    }

    // -------------------- getter and setter alongside variables for buff stuff --------------------

    float fire_rate;
    float additional_fire_rate;
    float primary_timer;               // acts as the timer for shooting cooldown

    int gun_level;
    int additional_gun_level;

    int bullet_damage;
    int additional_bullet_damage;


    public float get_fire_rate()
    {
        return fire_rate + get_additional_fire_rate();
    }

    public float get_additional_fire_rate()
    {
        return additional_fire_rate;
    }

    public void set_additional_fire_rate(float number)
    {
        additional_fire_rate = number;
    }


    public int get_gun_level()
    {
        return gun_level + get_additional_gun_level();
    }

    public int get_additional_gun_level()
    {
        return additional_gun_level;
    }

    public void set_additional_gun_level(int number)
    {
        additional_gun_level = number;
    }

    
    public int get_bullet_damage()
    {
        return bullet_damage + get_additional_bullet_damage();
    }

    public int get_additional_bullet_damage()
    {
        return additional_bullet_damage;
    }

    public void set_additional_bullet_damage(int number)
    {
        additional_bullet_damage = number;
    }

    // --------------------  --------------------



    // Start is called before the first frame update
    void Start()
    {
        // init for secondary weapon (homing bullets)
        storage_limit = 4;
        storage = storage_limit;
        storage_recharge = 2;
        storage_timer = 0;
        secondary_timer = 0.1f;
        secondaryWeapon.SetMaxWeaponCharge(storage_limit);

        // init for buff stuff
        fire_rate = 100;
        set_additional_fire_rate(0);

        gun_level = 0;
        set_additional_gun_level(0);

        bullet_damage = 3;
        set_additional_bullet_damage(0);


        // init for the laser
        laser_max_charge = 10;
        laser_charge = 0;
    }


    // Update is called once per frame
    void Update()
    {
        primary_timer -= Time.deltaTime;
        secondary_timer -= Time.deltaTime;
        storage_timer += Time.deltaTime;

        // getting more ammunition for secondary wapon
        if (storage_timer > storage_recharge)
        {
            storage_timer = 0;
            if (storage < storage_limit)
            {
                storage++;
                secondaryWeapon.SetWeaponCharge(storage);
            }

        }

        // shooting the laser
        shoot_laser();

        // shooting the primary weapon
        shoot_primary_weapon();

        // shooting the secondary weapon
        shoot_secondary_weapon();
    }

    void shoot_laser()
    {
        // the Player needs at least 1 laser_charge to be able to shoot the laser
        if (Input.GetKeyDown(KeyCode.Q) && laser_charge > 0)
        {
            // spawn the laser at a appropriate position (above the Player)
            GameObject laserbeam = Instantiate(laser, transform.position + new Vector3(0, transform.localScale.y, 0), Quaternion.identity);
            
            // init stats of the laser (damage, irrelevant movement speed, source)
            laserbeam.GetComponent<Bullet_Stats>().init(f(laser_charge), 1, "Player");

            // make the laser wider based on the number of laser_charges used
            laserbeam.transform.localScale = new Vector3(laser_charge * 0.1f + 0.1f, 1, 1);
            laser_charge = 0;
        }
    }


    void shoot_primary_weapon()
    {
        // no shooting input or timer has not yet expired -> no need to do anything further
        if (!(Input.GetKey(KeyCode.Space) && primary_timer < 0))
        {
            return;
        }


        // setting a cooldown until the next bullet can be shot (decreases with buff 1)
        primary_timer = 60 / get_fire_rate();
        GameObject bullet;

        // spawning the bullet based of the gun level (increases with buff 2)
        switch (get_gun_level())
        {
            case 0: // bullet of type 1
                bullet = Instantiate(bullet_1, transform.position, Quaternion.identity);    
                break;

            case 1: // bullet of type 2
                bullet = Instantiate(bullet_2, transform.position, Quaternion.identity);    
                break;

            default: // bullet of type 3
                bullet = Instantiate(bullet_3, transform.position, Quaternion.identity);    

                // setting the tracking multiplier based on the gun level
                bullet.GetComponent<Bullet_Movement_3>().set_tracking_multiplier(300 / get_gun_level());
                break;
        }

        // init stats of the bullet (damage whicht increases with buff 3, movement speed, source)
        bullet.GetComponent<Bullet_Stats>().init(get_bullet_damage(), 5, "Player");
    }


    void shoot_secondary_weapon()
    {
        // pressed enter key or (holding enter key and timer has expired)
        // - made this way so holding can be used instead of pressing the key multiple times
        // - holding the key should not create a bullet frame after frame
        bool pressed_the_key = Input.GetKeyDown(KeyCode.Return) || (Input.GetKey(KeyCode.Return) && secondary_timer < 0);

        // successful key input andleftover ammunition to shoot 
        if (pressed_the_key && storage > 0)
        {
            secondary_timer = 0.15f;
            storage--;
            secondaryWeapon.SetWeaponCharge(storage);

            // create bullet of type 3
            GameObject bullet = Instantiate(bullet_3, transform.position, Quaternion.identity);

            // init stats of the bullet (damage, movement speed, source)
            bullet.GetComponent<Bullet_Stats>().init(7, 5, "Player");

            // make the tracking multiplier very aggressive
            bullet.GetComponent<Bullet_Movement_3>().set_tracking_multiplier(1);

            // make the bullet pierce other bullets
            bullet.GetComponent<Bullet_Collision>().set_piercing();
        }
    }


    // fancy function for the laser damage scaling
    int f(int n)
    {
        int[] a = {1, 1};

        for (int i = 0; i < n; i++)
        {
            a[i % 2] = a[0] + a[1];
        }
        return Mathf.Max(a);
    }
}