using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class spawner_boss1 : MonoBehaviour
{
    //Bossminionspawner
    public GameObject boss_enemy;   //name des Minion: MINIOM! :D
    

    public int minioms_neu;
    public int miniom_alive;
    int minioms_max;

    int randoom;

    float timer;
    float my_spawnrate = 1;

    // Start is called before the first frame update
    void Start()
    {
        minioms_neu = 3;
        randoom = 1;
        minioms_max = 4;
    }

    // Update is called once per frame
    void Update()
    {
        if (miniom_alive < minioms_max)       //es sollen immer nur 4 Minioms gleichzeitig spawnen
        {
            if (timer < my_spawnrate)
            {
                timer += Time.deltaTime;
            }
            else
            {
                if(randoom == 1)    //spawnen entweder links oder rechts vom Boss
                {
                    Instantiate(boss_enemy, new Vector3(transform.position.x+2, transform.position.y - 1, 0), transform.rotation);
                }
                else
                {
                    Instantiate(boss_enemy, new Vector3(transform.position.x-2, transform.position.y - 1, 0), transform.rotation);
                }
                
                timer = 0;
                miniom_alive++;
                randoom = Random.Range(1, 3);
            }
        }
    }
    //Respawner wenn alle Minioms down
    public void set_alive()
    {
        minioms_neu--;
        if (minioms_neu == 0)
        {
            miniom_alive = 0;
            minioms_neu = 4;
        }
    }

    public void set_minioms(int i)
    {
        minioms_max = i;
    }
}
