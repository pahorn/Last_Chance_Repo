using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Shield_Health : Health
{
    int max_health;
    int health;

    string bullet_type;


    override public int get_max_health()
    {
        return max_health;

    }

    override public int get_health()
    {
        return health;
    }

    void Start()
    {
        max_health = 5;
        //Leben der einzelnen Schildtypen
        if (gameObject.name == "green_shield(Clone)")
        {
            max_health *= 5;
        }
        else if (gameObject.name == "lila_shield(Clone)")
        {
            max_health *= 4;
        }
        else
        {
            max_health *= 3;
        }
        health = max_health;
    }

    public void set_bullet_type(string i)
    {
        bullet_type = i;
    }

    //Jedes Schild bekommt nur von dem Geschoss Schaden das die gleiche Farbe hat
    override public void receive_damage(int damage)
    {
        if (gameObject.name == "green_shield(Clone)")
        {
            if (bullet_type == "Bullet_1(Clone)")
            {
                health--;
            }
        }
        if (gameObject.name == "red_shield(Clone)")
        {
            if (bullet_type == "Bullet_2(Clone)")
            {
                health--;
            }
        }
        else
        {
            if (bullet_type == "Bullet_3(Clone)")
            {
                health--;
            }
        }
        if (health < 1)
        {
            Destroy(this.gameObject);
        }
    }

    //lvlwechsel
    public void OnDestroy()
    {
        GameObject shield = GameObject.FindGameObjectWithTag("Boss");

        if (shield != null)
        {
            shield.GetComponent<boss1_shields>().set_shield(false);
            if (shield.GetComponent<boss1_shields>().get_lila())
            {
                shield.GetComponent<spawner_boss1>().set_minioms(5);
            }

        }
    }
}
