using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Boss1_Health : Health
{   // Start is called before the first frame update

    int max_health;
    int health;
    GameObject lvl;

    boss1_shields shield;

    public Health_Bar healthBar;

    
    public void set_max_health(int number)
    {
        max_health = number;
        health = max_health;
    }

    override public int get_max_health()
    {
        return max_health;
    }

    override public int get_health()
    {
        return health;
    }

    void Start()
    {
        max_health = 300;
        health = max_health;

        shield = GameObject.FindGameObjectWithTag("Boss").GetComponent<boss1_shields>();
        lvl = GameObject.FindGameObjectWithTag("lvl");
        healthBar.SetMaxHealth(max_health);
    }


    override public void receive_damage(int damage)
    {
    //wenn ein Schild aktiv ist, soll der Boss keinen Schaden bekommen. Auch nicht von piercing Angriffen wie dem Laser
        if (!shield.shield_active)   
        {
            health -= damage;
            if (health < 1)
            {
                GameObject.Find("Buff_Manager").GetComponent<Buff_Management>().spawn_buff(this.transform.position);
                Destroy(this.gameObject);
            }
            if (health > max_health)
            {
                health = max_health;
            }
            healthBar.SetHealth(health);
        }
    }

    //bei Tod des Bosses -> Lvlwechsel
    private void OnDestroy()
    { 
        if(lvl!= null)
        {
            lvl.GetComponent<lvl>().win_lvl();
        }
    }
}
