using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class boss1_shields : MonoBehaviour
{
    public GameObject green;
    public GameObject red;
    public GameObject lila;
    public bool shield_active;

    GameObject boss_health;
    int pr�fwert;
    bool red_shield;
    bool lila_shield;

    // Start is called before the first frame update
    void Start()
    {
        Instantiate(green, new Vector3(transform.position.x, transform.position.y, 0), transform.rotation);
        shield_active = true;

        boss_health = GameObject.FindGameObjectWithTag("Boss");
        pr�fwert = boss_health.GetComponent<Boss1_Health>().get_max_health()/3;
        
        red_shield = false;
        lila_shield = false;
    }

    // Update is called once per frame
    void Update()
    {
        if (shield_active)      //Schild active?
        {
            return;
        }
                                //wenn nein, pr�fe das Leben des Bosses
        if (boss_health.GetComponent<Boss1_Health>().get_health() <= pr�fwert * 2 && !red_shield)   //bei 2/3 rotes Schild
        {
            Instantiate(red, new Vector3(transform.position.x, transform.position.y, 0), transform.rotation);
            shield_active = true;
            red_shield = true;


        } else if(boss_health.GetComponent<Boss1_Health>().get_health() <= pr�fwert && !lila_shield)    //bei 1/3 lila Schild 
        {
            Instantiate(lila, new Vector3(transform.position.x, transform.position.y, 0), transform.rotation);
            shield_active = true;
            lila_shield = true;
        }                    
    }

    public bool get_lila()
    {
        return lila_shield;
    }

    public bool get_shield()
    {
        return shield_active;
    }

    public void set_shield(bool i)
    {
        shield_active = i;
    }
}
