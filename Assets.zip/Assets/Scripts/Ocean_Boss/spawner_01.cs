using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class spawner_01 : MonoBehaviour
{
    //gebrauchte variablen
    public Wave_UI waveUI;

    //gegner spawn und wellen spawn
    int wave_counter = 1;
    [SerializeField]
    int wave_end = 4;

    //pause zwischen wellen variablen
    float wave_pause = 5;
    float wave_timer = 0;

    //zufallsgrenzen
    int low_num = 5;
    int high_num = 20;

    //schnittvariable
    lvl lvl;

    //gegner
    public GameObject enemy;
    public GameObject enemy2;
    public GameObject enemy3;
    public GameObject enemy4;

    //spawner variablen
    float my_spawnrate = 1;
    float timer = 0;
    int my_offset = 2;

    // Start is called before the first frame update
    void Start()
    {
        lvl = GameObject.FindGameObjectWithTag("lvl").GetComponent<lvl>();
        lvl.enemy_count = ran_num(low_num, high_num);         //enemy_counter für diese Welle
        waveUI.setMaxWave(wave_end);
    }

    // Update is called once per frame
    void Update()
    {//spawnt solange Gegner bis genug Gegner auf dem Feld sind oder keine neuen spawnen sollen
        if (lvl.enemy_count > 0 && lvl.enemy_alive <= 4)        
        {
            if (timer < my_spawnrate)
            {
                timer += Time.deltaTime;
            }
            else
            {
                spawning();
                timer = 0;
            }
        }
        else if(lvl.enemy_alive<= 0)
        {

            wave_counter_manager();

        }

    }

    //spawnt einen von 4 Gegnerntypen
    void spawning()
    {
        float left = transform.position.x - my_offset;
        float right = transform.position.x + my_offset;

        float num = Random.Range(0, 12);        //random gegner generator

        if (num < 4)
        {
            Instantiate(enemy, new Vector3(Random.Range(left, right), transform.position.y-2, 0), transform.rotation);
        }
        else if (num < 8)
        {
            Instantiate(enemy2, new Vector3(Random.Range(left, right), transform.position.y-2, 0), transform.rotation);
        }
        else if (num < 10)
        {
            Instantiate(enemy3, new Vector3(Random.Range(left, right), transform.position.y-2, 0), transform.rotation);
        }
        else
        {
            Instantiate(enemy4, new Vector3(Random.Range(left, right), transform.position.y-2, 0), transform.rotation);
        }
        //verringert die Anzahl an Gegnern die noch gespawnt werden muss und zählt mit wie viele gleichzeitig auf dem Feld sind
        lvl.decrease_enemy_counter();
        lvl.increase_enemy_alive();
        
    }

    public void wave_counter_manager()
    {//Wellenzähler
        if(wave_counter < wave_end)
        {//Pause zwischen den Wellen
            if(wave_timer < wave_pause)
            {
                wave_timer += Time.deltaTime;
            }
            else
            {
                wave_counter++;     
                lvl.enemy_count = ran_num(low_num, high_num);   //neue Menge an Gegnern für die nächste Welle
                wave_timer = 0;
                waveUI.setCurrentWave(wave_counter);
            }

        }
        else
        {
            lvl.win_lvl();      //levelwechsel
        } 
    }

    public int ran_num(int i, int u)    //zufallszahlengenerator 
    {
        return Random.Range(i, u);
    }
}
