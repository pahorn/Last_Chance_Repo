using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Tutorial_Manager : MonoBehaviour
{

    [SerializeField]
    string[] text_of_tutorial;
    int step_counter;

    [SerializeField]
    GameObject enemy;

    [SerializeField]
    Text tutorial_text;

    // Start is called before the first frame update
    void Start()
    {
        step_counter = 0;
        tutorial_text.text = text_of_tutorial[step_counter];
    }

    // Update is called once per frame
    void Update()
    {
        bonus_inputs();

        if (Input.GetKeyDown(KeyCode.N))
        {
            step_counter = Mathf.Min(step_counter+1, text_of_tutorial.Length-1);
            // TODO : aktualisiere das Textfeld
            tutorial_text.text = text_of_tutorial[step_counter];
        }

        if (Input.GetKeyDown(KeyCode.M))
        {
            step_counter = Mathf.Max(step_counter-1, 0);
            // TODO : aktualisiere das Textfeld
            tutorial_text.text = text_of_tutorial[step_counter];
        }
    }

    void bonus_inputs()
    {
        buff_input();
        laser_input();
        enemy_input();
    }

    void buff_input()
    {
        if (Input.GetKeyDown(KeyCode.B) && step_counter >= 7)
        {
            GameObject buff_manager = GameObject.Find("Buff_Manager");
            float x = Random.Range(-3.5f, 3.5f);
            buff_manager.GetComponent<Buff_Management>().spawn_buff(new Vector3(x,0,0));
        } 
    }

    void laser_input()
    {
        if (Input.GetKeyDown(KeyCode.L) && step_counter >= 6)
        {
            GameObject player = GameObject.FindGameObjectWithTag("Player");
            player.GetComponent<Gun>().increase_laser_charge();
        }
    }

    void enemy_input()
    {
        if (Input.GetKeyDown(KeyCode.E) && step_counter >= 8)
        {
            GameObject e = Instantiate(enemy, new Vector3(0,3,0), Quaternion.identity);
            e.transform.rotation = Quaternion.Euler(0, 0, 180);
        }
    }
}
