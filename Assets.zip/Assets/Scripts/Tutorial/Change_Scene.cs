using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Change_Scene : MonoBehaviour
{
    [SerializeField]
    string scene_name;

    public void change_scene()
    {
         SceneManager.LoadScene(scene_name);
    }
}
