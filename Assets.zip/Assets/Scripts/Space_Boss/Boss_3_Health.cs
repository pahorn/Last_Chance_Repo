using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Boss_3_Health : Health
{
    [SerializeField]
    int max_health;
    [SerializeField]
    int health;

    bool phase_2;

    public Health_Bar healthBar;

    public void set_max_health(int number)
    {
        max_health = number;
        health = max_health;
    }

    override public int get_max_health()
    {
        return max_health;
    }

    override public int get_health()
    {
        return health;
    }

    void Start()
    {
        if(max_health == default)
        {
            max_health = 1000;
        }
        health = max_health;
        healthBar.SetMaxHealth(max_health);
        phase_2 = false;
    }

    // additional function because the boss has its own armor
    public void receive_damage(int damage, bool valid)
    {
        // every non valid hit will be reduced to 1
        damage = (valid) ? damage : 1;
        
        if (phase_2 && damage < 50 && damage > 0)
        {
            damage = Mathf.CeilToInt(damage / 3);
        }

        health -= damage;
        if (health < 1)
        {
            // spawning a buff on the "dead" boss position
            GameObject buff_manager = GameObject.Find("Buff_Manager");
            if (buff_manager != null)
            {
                buff_manager.GetComponent<Buff_Management>().spawn_buff(this.transform.position);
            }
            Destroy(this.gameObject);
        }

        // preventing overheal
        health = Mathf.Min(health, max_health);


        if (health < max_health /2 && !phase_2) 
        {
            Turret_Gun_Control tgc = GetComponent<Turret_Gun_Control>();
            if (tgc != null)
            {
                tgc.increase_maximum_turret_guns();
                tgc.increase_maximum_turret_guns();
            }
            phase_2 = true;
        }


        healthBar.SetHealth(health);
    }

    // standard receive_damage function which will be called from by all "Player" bullets (excepts the laser)
    override public void receive_damage(int damage)
    {
        receive_damage(damage, false);
    }
}
