using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bullet_for_Turret_Gun_Collision : MonoBehaviour
{
    Bullet_Stats bullet_Stats;

    // Start is called before the first frame update
    void Start()
    {
        bullet_Stats = GetComponent<Bullet_Stats>();
    }

    // marker bullet collides with something
    private void OnTriggerEnter2D(Collider2D collision)
    {
        /*
        in short:
            - only collisions with "Boss" or "Player" matter (in terms of dealing damage)
            - bullets can be destroyed with player bullets
         
        */

        string collision_tag = collision.gameObject.tag;

        // bullets hits another "Bullet"
        if (collision_tag == "Bullet")
        {
            // Destroy unless it's source is "Enemy" (Player can destroy those bullets)
            string other_bullet_sourve = collision.gameObject.GetComponent<Bullet_Stats>().get_source();
            if (other_bullet_sourve != "Enemy")
            {
                Destroy(this.gameObject);
            }
            return;
        }

        // bullet hits a "Boss" -> deal true damage to the boss
        if (collision_tag == "Boss")
        {
            Boss_3_Health collision_health = collision.gameObject.GetComponent<Boss_3_Health>();

            collision_health.receive_damage(bullet_Stats.get_damage(), true);
            Destroy(this.gameObject);
        }

        // bullet hits a "Player" -> deal damage
        if (collision_tag == "Player")
        {
            Player_Health collision_health = collision.gameObject.GetComponent<Player_Health>();
            
            collision_health.receive_damage(bullet_Stats.get_damage());
            Destroy(this.gameObject);
        }
    }


    // bullet leaves something that it had a collision earlier
    private void OnTriggerExit2D(Collider2D collision)
    {
        // leaving the background a.k.a bullet needs to be destroyed
        // otherwise the bullet would fly indefinitly and exist forever
        if (collision.tag == "Background")
        {
            Destroy(this.gameObject);
        }
    }
}
