using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Turret_Gun_Control : MonoBehaviour
{
    int maximum_turret_guns;
    int current_turret_guns;

    float turret_gun_spawn_timer;

    float turret_gun_spawn_cooldown;
    float min_turret_gun_spawn_cooldown;
    float max_turret_gun_spawn_cooldown;

    float min_x;
    float max_x;

    float min_y;
    float max_y;

    [SerializeField]
    GameObject turret_gun;

    GameObject enemy_playfield;

    Vector3[] turret_gun_array;



    // Start is called before the first frame update
    void Start()
    {
        maximum_turret_guns = 4;
        current_turret_guns = 0;

        max_turret_gun_spawn_cooldown = 6;
        min_turret_gun_spawn_cooldown = 1;

        turret_gun_spawn_cooldown = min_turret_gun_spawn_cooldown;
        turret_gun_spawn_timer = turret_gun_spawn_cooldown;

        enemy_playfield = GameObject.Find("Enemy_Playfield");

        min_x = enemy_playfield.transform.position.x - enemy_playfield.transform.lossyScale.x / 2 + 1;
        max_x = enemy_playfield.transform.position.x + enemy_playfield.transform.lossyScale.x / 2 - 1;

        min_y = enemy_playfield.transform.position.y - enemy_playfield.transform.lossyScale.y / 2 + 1;
        max_y = enemy_playfield.transform.position.y + enemy_playfield.transform.lossyScale.y / 2 - 1;

        turret_gun_array = new Vector3[6];
        for (int i = 0; i < turret_gun_array.Length; i++)
        {
            turret_gun_array[i] = new Vector3(0, 0, 0);
        }
    }

    // Update is called once per frame
    void Update()
    {
        turret_gun_spawn_timer -= Time.deltaTime;

        if (turret_gun_spawn_timer < 0 && current_turret_guns < maximum_turret_guns)
        {
            spawn_turret_gun();
        }
    }

    public void turret_gun_destroyed(Vector3 position)
    {
        if (current_turret_guns == maximum_turret_guns) 
        {
            turret_gun_spawn_timer = turret_gun_spawn_cooldown;
        }

        current_turret_guns--;

        if (current_turret_guns == 0)
        {
            turret_gun_spawn_cooldown = min_turret_gun_spawn_cooldown;
            turret_gun_spawn_timer = turret_gun_spawn_cooldown;
        }

        for (int i = 0; i < turret_gun_array.Length; i++)
        {
            if (turret_gun_array[i] == position)
            {
                turret_gun_array[i] = new Vector3(0, 0, 0);
                break;
            }
        }
    }

    void spawn_turret_gun()
    {
        current_turret_guns++;

        turret_gun_spawn_timer = turret_gun_spawn_cooldown;

        if (current_turret_guns  == maximum_turret_guns)
        {
            turret_gun_spawn_cooldown = max_turret_gun_spawn_cooldown;
        }

        Vector3 position = get_good_random_position();

        GameObject created_turret_gun = Instantiate(turret_gun, position, Quaternion.identity);
        created_turret_gun.transform.rotation = Quaternion.Euler(0, 0, 180);
        
        // TODO: give turrets some kind of ID
        //  - update on TODO: not needed if Turret Guns don't move

        for (int i = 0; i < turret_gun_array.Length; i++)
        {
            if (turret_gun_array[i] == new Vector3(0,0,0))
            {
                turret_gun_array[i] = position;
                break;
            }
        }
    }

    public void signal_to_shoot(Vector3 position)
    {

        GameObject[] guns = GameObject.FindGameObjectsWithTag("Enemy");

        for (int i = 0; i < guns.Length; i++)
        {
            Burst_Fire burst_Fire = guns[i].GetComponent<Burst_Fire>();
            if (burst_Fire != null)
            {
                burst_Fire.open_fire(position);
            }
        }
    }

    public void signal_to_shoot(GameObject target)
    {
        GameObject[] guns = GameObject.FindGameObjectsWithTag("Enemy");

        for (int i = 0; i < guns.Length; i++)
        {
            Burst_Fire burst_Fire = guns[i].GetComponent<Burst_Fire>();
            if (burst_Fire != null)
            {
                burst_Fire.open_fire(target);
            }
        }
    }

    Vector3 get_good_random_position()
    {
        while (true)
        {
            float x = Random.Range(min_x, max_x);
            float y = Random.Range(min_y, max_y);
            bool good_enough = true;

            Vector3 position = new Vector3(x, y, 0);

            for (int i = 0; i < turret_gun_array.Length; i++)
            {
                float dist = (position - turret_gun_array[i]).magnitude;

                if (dist < 1 && turret_gun_array[i] != new Vector3(0,0,0))
                {
                    good_enough = false;
                }
            }

            if (good_enough)
            {
                return position;
            }
        }
    }

    public void increase_maximum_turret_guns()
    {
        maximum_turret_guns++;
    }
}
