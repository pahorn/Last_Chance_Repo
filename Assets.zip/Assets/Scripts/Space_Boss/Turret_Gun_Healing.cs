using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Turret_Gun_Healing : MonoBehaviour
{
    float timer_alive;

    // Start is called before the first frame update
    void Start()
    {
        timer_alive = 0;   
    }

    // Update is called once per frame
    void Update()
    {
        timer_alive += Time.deltaTime;
        
        if (timer_alive > 10)
        {
            GameObject boss = GameObject.FindGameObjectWithTag("Boss");
            if (boss != null)
            {
                boss.GetComponent<Boss_3_Health>().receive_damage(-50, true);
            }
            timer_alive = 0;
        }
    }
}
