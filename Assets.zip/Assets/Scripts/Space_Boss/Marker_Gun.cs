using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Marker_Gun : MonoBehaviour
{
    /*
     Implementation how the marker bullets are fired 
        - currently only used in the fight with Boss_3
        - using it in a different enviroment may lead to errors
     */

    public GameObject bullet_marker;  // more or less just a bullet 4 type (different collision behaviour)
    
    float temp_timer;                   // acts as the timer for shooting cooldown
    [SerializeField]
    float fire_rate;                    // self explaining
    [SerializeField]
    int bullet_speed;

    // Start is called before the first frame update
    void Start()
    {
        if (fire_rate == default)
        {
            fire_rate = 40;
        }
        if (bullet_speed == default)
        {
            bullet_speed = 6;
        }
        temp_timer = 60 / fire_rate;
    }


    // Update is called once per frame
    void Update()
    {
        temp_timer -= Time.deltaTime;

        if (temp_timer < 0)
        {
            shoot_tracking_bullet();
        }
    }


    void shoot_tracking_bullet()
    {
        // setting a cooldown until the next bullet can be shot 
        temp_timer = 60 / fire_rate;

        // create a marker bullet
        GameObject bullet = Instantiate(bullet_marker, transform.position, Quaternion.identity);    
        
        // init stutff for the created bullet
        bullet.GetComponent<Bullet_Movement_3>().set_tracking_multiplier(10);
        bullet.GetComponent<Bullet_Stats>().init(0, bullet_speed, this.tag);
    }
}