using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Burst_Fire : MonoBehaviour
{
    /*
     Implementation of how the Turret Guns of Boss_3 are shooting
        - currently only used in the fight with Boss_3
        - using it in a different enviroment may lead to errors
     */

    [SerializeField]
    GameObject bullet_for_turret_gun;

    float burst_cooldown;
    float burst_cooldown_timer;

    float burst_delay;
    float burst_delay_timer;

    int number_of_shots;
    int remaining_shots;

    Vector3 target_position;
    GameObject target;

    // Start is called before the first frame update
    void Start()
    {
        burst_cooldown = 0;
        burst_cooldown_timer = 0;

        burst_delay = 0.1f;
        burst_delay_timer = 0;

        remaining_shots = 0;
        number_of_shots = 3;

        target = null;
    }

    // Update is called once per frame
    void Update()
    {
        burst_delay_timer -= Time.deltaTime;
        burst_cooldown_timer -= Time.deltaTime;

        if (burst_cooldown_timer > 0)
        {
            return;
        }

        if (burst_delay_timer < 0 && remaining_shots > 0)
        {
            remaining_shots--;
            burst_delay_timer = burst_delay;
            shoot();

            if (remaining_shots == 0)
            {
                burst_cooldown_timer = burst_cooldown;
            }
        }
    }

    // fire a burst towards a position
    public void open_fire(Vector3 position)
    {
        // already shooting a burst -> do not create a new burst
        // burst on cooldown -> do not create a new burst
        if (remaining_shots > 0 || burst_cooldown_timer > 0)
        {
            return;
        }
        target = null;

        target_position = position;

        remaining_shots = number_of_shots;
        burst_delay_timer = burst_delay;
    }

    // fire a burst towards a gameobject (later shots of the burst will calculate their start direction again the target)
    public void open_fire(GameObject other)
    {
        // already shooting a burst -> do not create a new burst
        // burst on cooldown -> do not create a new burst
        if (remaining_shots > 0 || burst_cooldown_timer > 0)
        {
            return;
        }

        target = other;

        remaining_shots = number_of_shots;
        burst_delay_timer = burst_delay;
    }

    // create the bullet
    void shoot()
    {
        if (target != null)
        {
            target_position = target.transform.position;
        }

        GameObject bullet = Instantiate(bullet_for_turret_gun, transform.position, Quaternion.identity);
        bullet.GetComponent<Bullet_for_Turret_Gun_Movement>().change_trajectory(target_position);
        bullet.GetComponent<Bullet_Stats>().init(20, 13, "Enemy");
    }
}
