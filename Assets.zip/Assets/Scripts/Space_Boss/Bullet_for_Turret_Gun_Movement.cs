using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bullet_for_Turret_Gun_Movement : MonoBehaviour
{
    /*
     Handles the movement of the bullet for turret guns (more or less bullet type 2)
     */

    Vector3 dir;                    // direction in which the bullet will move
    Bullet_Stats stats;

    // Start is called before the first frame update
    void Start()
    {
        stats = GetComponent<Bullet_Stats>();
    }

    public void change_trajectory(Vector3 target_position)
    {
        float y_sec_dir = target_position.y - transform.position.y;
        y_sec_dir = (y_sec_dir > 0) ? 1 : -1;

        Vector3 sec_dir = new Vector3(0, y_sec_dir, 0);

        dir = target_position - transform.position;
        dir = dir.normalized;


        // math to adjust the rotation of the bullet strike
        //  - making it look like it's in line between shooter and target

        // angle between calculated direction and base direction of bullet type 1
        float angle = Mathf.Acos(Vector3.Dot(sec_dir, dir) / (sec_dir.magnitude * dir.magnitude)) / Mathf.PI * 180;


        Transform child = this.transform.GetChild(0);
        angle *= (dir.x > 0) ? -1 : 1;
        child.rotation = Quaternion.Euler(child.eulerAngles.x, child.eulerAngles.y, angle * sec_dir.y + child.eulerAngles.z);
    }

    // Update is called once per frame
    void Update()
    {
        transform.position += dir * stats.get_speed() * Time.deltaTime;
    }
}
