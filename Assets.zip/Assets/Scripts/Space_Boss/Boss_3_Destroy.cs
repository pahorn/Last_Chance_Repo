using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Boss_3_Destroy : MonoBehaviour
{
    /*
     Handles the Destruction of Boss_3
     */

    private void OnDestroy()
    {
        // win level
        GameObject lvl = GameObject.FindGameObjectWithTag("lvl");
        if (lvl != null)
        {
            lvl.GetComponent<lvl>().win_lvl();
        }

        // get all remaining objects with tag "Enemy"
        GameObject[] all_enemies = GameObject.FindGameObjectsWithTag("Enemy");

        if (this.GetComponent<Boss_3_Health>().get_health() > 0)
        {
            return;
        }

        // try to delete all Guns
        for (int i = 0; i < all_enemies.Length; i++)
        {
            Destroy(all_enemies[i]);
        }
    }
}
