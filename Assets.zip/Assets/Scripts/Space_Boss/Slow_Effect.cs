using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Slow_Effect : MonoBehaviour
{
    /*
     Script which Slows the Movement of the gameobject that it is attached to
        - currently only used in Boss_3
        - therefore other uses in different enviroment may lead to errors
     */

    Movement movement;              // some kind of movement class (of a movement script)
    float timer;                    // acts as a timer for the slow effect
    float duration;                 // how long the slow is in effect
    float og_speed;                 // the speed of the gameobject when no slows are affecting it
    float debuff_multiplier;        // multiplier how slow the movement under the effect will be


    // Start is called before the first frame update
    void Start()
    {
        duration = 1f;
        timer = duration;
        debuff_multiplier = 0.1f;

        if (gameObject.tag == "Player")
        {
            movement = gameObject.GetComponent<Player_Movement>();
        }
        else
        {
            movement = gameObject.GetComponent<Screen_Saver_Movement>();
        }
        
        og_speed = movement.get_speed();                    // getting the original movement speed of the gameobject
        movement.set_speed(og_speed * debuff_multiplier);   // setting the movement speed to a slowed version
    }

    // Update is called once per frame
    void Update()
    {
        timer -= Time.deltaTime;
        
        if (timer < 0)
        {
            movement.set_speed(og_speed);       // returning to the original movement speed
            Destroy(this);                      // Detaching the script by destroying it
        }
    }
}
