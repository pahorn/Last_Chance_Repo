using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Turret_Gun_Destroy : MonoBehaviour
{
    private void OnDestroy()
    {
        GameObject boss = GameObject.FindGameObjectWithTag("Boss");

        if (boss != null)
        {
            boss.GetComponent<Turret_Gun_Control>().turret_gun_destroyed(transform.position);
            boss.GetComponent<Boss_3_Health>().receive_damage(100, true);
        }
    }
}
