using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Marker_Collision : MonoBehaviour
{
    Bullet_Stats bullet_Stats;

    // Start is called before the first frame update
    void Start()
    {
        bullet_Stats = GetComponent<Bullet_Stats>();
    }


    // marker bullet collides with something
    private void OnTriggerEnter2D(Collider2D collision)
    {
        /*
        in short:
            - if source == "Boss" only the collision with Player or bullet from Player is relevant
                - collision with bullet from Player leads to destruction of marker bullet
                - collision with Player
                    - leads to rewrite of bullet if "Player" is dodging
                    - leads to destruction of marker bullet otherwise
           

            - if source == "Player" only the collision with "Boss" is relevant 
                - leads to desctruction of marker bullet
        */

        string collision_tag = collision.gameObject.tag;

        // bullet is coming from the boss towards the player
        if (bullet_Stats.get_source() == "Boss")
        {
            // collision with a "Player" -> parry the bullet if dodging; otherwise send signal and add slow effect
            if (collision_tag == "Player")
            {
                Player_Health player_Health = collision.gameObject.GetComponent<Player_Health>();
                player_Health.receive_damage(bullet_Stats.get_damage());

                bool dodging = collision.gameObject.GetComponent<Player_Movement>().dodge_invincibility();

                if (dodging)
                {
                    GetComponent<Bullet_Movement_3>().change_target(GameObject.Find("Boss"));
                    bullet_Stats.set_source("Player");
                } else
                {
                    send_signal(collision.gameObject);
                    collision.gameObject.AddComponent<Slow_Effect>();
                    Destroy(this.gameObject);
                }
            }

            // collision with a "Bullet" -> send signal (if it was a "Player" bullet)
            if (collision_tag == "Bullet")
            {
                Bullet_Stats other_bullet = collision.gameObject.GetComponent<Bullet_Stats>();
                if (other_bullet.get_source() == "Player")
                {
                    send_signal(this.transform.position);
                    Destroy(this.gameObject);
                }
            }
        }

        // bullet was already parried and is now colliding with the boss -> send signal and add the slow effect
        if (bullet_Stats.get_source() == "Player")
        {
            if (collision_tag == "Boss")
            {
                send_signal(collision.gameObject);
                collision.gameObject.AddComponent<Slow_Effect>();
                Destroy(this.gameObject);
            }

        }

    }

    // bullet leaves something that it had a collision earlier
    private void OnTriggerExit2D(Collider2D collision)
    {
        // leaving the background a.k.a bullet needs to be destroyed
        // otherwise the bullet would fly indefinitly and exist forever
        if (collision.tag == "Background")
        {
            Destroy(this.gameObject);
        }
    }

    // send a signal to the control unit that all turret guns should shoot towards the given position
    void send_signal(Vector3 position)
    {
        GameObject boss = GameObject.FindGameObjectWithTag("Boss");

        if (boss != null)
        {
            boss.GetComponent<Turret_Gun_Control>().signal_to_shoot(position);
        }
    }

    // send a signal to the control unit that all turret guns should shoot towards the given gameobject
    void send_signal(GameObject target)
    {
        GameObject boss = GameObject.FindGameObjectWithTag("Boss");

        if (boss != null)
        {
            boss.GetComponent<Turret_Gun_Control>().signal_to_shoot(target);
        }
    }
}
