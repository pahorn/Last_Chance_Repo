using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Spawn_Rand : MonoBehaviour
{
    // Start is called before the first frame update
    public GameObject rand;
    [SerializeField]
    float timer;
    [SerializeField]
    float spawnrate;

    void Start()
    {
        spawnrate = 2;
    }

    // Update is called once per frame
    void Update()
    {
        if(timer < spawnrate)
        {
            timer += Time.deltaTime;
            Debug.Log(timer);
        }
        else
        {
            Instantiate(rand, new Vector3(transform.position.x+4, transform.position.y, 0), transform.rotation);
            Instantiate(rand, new Vector3(transform.position.x-4, transform.position.y, 0), transform.rotation);
            timer = 0;
        }
        

    }
}
